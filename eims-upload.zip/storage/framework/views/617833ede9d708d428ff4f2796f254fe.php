﻿

<?php $__env->startSection('content'); ?>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
    body { background-color: #f8f9fc; }
    .lm-font { font-family: 'Inter', sans-serif; }
    
    /* Summary Cards */
    .lm-summary-card {
        background: #ffffff;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        padding: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    }
    .lm-summary-title { font-size: 0.8rem; color: #64748b; font-weight: 600; margin-bottom: 4px; }
    .lm-summary-value { font-size: 1.5rem; font-weight: 700; color: #1e293b; }
    .lm-summary-icon {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
    }
    .icon-total { background: #f1f5f9; color: #64748b; }
    .icon-pending { background: #fef3c7; color: #d97706; }
    .icon-approved { background: #dcfce7; color: #16a34a; }
    .icon-rejected { background: #fee2e2; color: #dc2626; }
    .icon-today { background: #e0e7ff; color: #4f46e5; }
    .text-pending { color: #d97706 !important; }
    .text-approved { color: #16a34a !important; }
    .text-rejected { color: #dc2626 !important; }
    .text-today { color: #4f46e5 !important; }

    /* Filters Section */
    .lm-filter-card {
        background: #ffffff;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        padding: 24px;
        margin-top: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    }
    .lm-filter-label { font-size: 0.75rem; font-weight: 700; color: #64748b; margin-bottom: 8px; display: block; }
    .lm-filter-select, .lm-filter-input {
        border-radius: 8px; border: 1px solid #cbd5e1; padding: 10px 14px; font-size: 0.85rem; width: 100%;
        color: #334155; font-weight: 500; outline: none; transition: border-color 0.2s;
    }
    .lm-filter-select:focus, .lm-filter-input:focus { border-color: #4f46e5; }

    /* Table Section */
    .lm-table-card {
        background: #ffffff;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        margin-top: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        overflow: hidden;
    }
    .lm-table-header { padding: 20px 24px; border-bottom: 1px solid #e2e8f0; font-weight: 700; color: #1e293b; font-size: 1.1rem; }
    .lm-table { width: 100%; border-collapse: collapse; }
    .lm-table th { background: #f8fafc; padding: 12px 24px; text-align: left; font-size: 0.7rem; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e2e8f0; }
    .lm-table td { padding: 16px 24px; border-bottom: 1px solid #f1f5f9; font-size: 0.85rem; color: #334155; vertical-align: middle; }
    .lm-table tr:last-child td { border-bottom: none; }
    
    .status-pill { padding: 4px 12px; border-radius: 20px; font-size: 0.7rem; font-weight: 700; }
    .pill-pending { background: #fef3c7; color: #b45309; }
    .pill-approved { background: #dcfce7; color: #15803d; }
    .pill-rejected { background: #fee2e2; color: #b91c1c; }

    .btn-action { padding: 6px 12px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; border: none; cursor: pointer; display: inline-flex; align-items: center; gap: 4px; transition: 0.2s; color: white; text-decoration: none; }
    .btn-approve { background: #16a34a; }
    .btn-approve:hover { background: #15803d; }
    .btn-reject { background: #dc2626; }
    .btn-reject:hover { background: #b91c1c; }

    .btn-primary-custom { background: #4f46e5; color: white; border-radius: 8px; padding: 10px 20px; font-weight: 600; border: none; font-size: 0.85rem; transition: background 0.2s; }
    .btn-primary-custom:hover { background: #4338ca; }
    .btn-outline-custom { background: white; color: #4f46e5; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px 20px; font-weight: 600; font-size: 0.85rem; transition: all 0.2s; }
    .btn-outline-custom:hover { background: #f8fafc; border-color: #4f46e5; }
</style>

<div class="lm-font pb-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold text-dark mb-1" style="font-size: 1.5rem;">Leave Management</h2>
            <p class="text-muted small mb-0">Manage employee leave requests and approvals</p>
        </div>
        <div>
            <form action="<?php echo e(route('admin.leave.index')); ?>" method="GET" class="d-inline">
                <input type="hidden" name="status" value="Pending">
                <button type="submit" class="btn-primary-custom">Pending Approvals</button>
            </form>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success border-0 shadow-sm" style="border-radius: 12px; font-size: 0.9rem; font-weight: 500;">
            <i class="fa-solid fa-check-circle me-2"></i><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Summary Cards -->
    <div class="row g-3">
        <div class="col-md-2 col-sm-6" style="width: 20%;">
            <div class="lm-summary-card">
                <div>
                    <div class="lm-summary-title">Total Requests</div>
                    <div class="lm-summary-value"><?php echo e($stats['total']); ?></div>
                </div>
                <div class="lm-summary-icon icon-total"><i class="fa-regular fa-file-lines"></i></div>
            </div>
        </div>
        <div class="col-md-2 col-sm-6" style="width: 20%;">
            <div class="lm-summary-card">
                <div>
                    <div class="lm-summary-title">Pending</div>
                    <div class="lm-summary-value text-pending"><?php echo e($stats['pending']); ?></div>
                </div>
                <div class="lm-summary-icon icon-pending"><i class="fa-regular fa-clock"></i></div>
            </div>
        </div>
        <div class="col-md-2 col-sm-6" style="width: 20%;">
            <div class="lm-summary-card">
                <div>
                    <div class="lm-summary-title">Approved</div>
                    <div class="lm-summary-value text-approved"><?php echo e($stats['approved']); ?></div>
                </div>
                <div class="lm-summary-icon icon-approved"><i class="fa-regular fa-circle-check"></i></div>
            </div>
        </div>
        <div class="col-md-2 col-sm-6" style="width: 20%;">
            <div class="lm-summary-card">
                <div>
                    <div class="lm-summary-title">Rejected</div>
                    <div class="lm-summary-value text-rejected"><?php echo e($stats['rejected']); ?></div>
                </div>
                <div class="lm-summary-icon icon-rejected"><i class="fa-regular fa-circle-xmark"></i></div>
            </div>
        </div>
        <div class="col-md-2 col-sm-6" style="width: 20%;">
            <div class="lm-summary-card">
                <div>
                    <div class="lm-summary-title">On Leave Today</div>
                    <div class="lm-summary-value text-today"><?php echo e($stats['on_leave_today']); ?></div>
                </div>
                <div class="lm-summary-icon icon-today"><i class="fa-solid fa-user-group"></i></div>
            </div>
        </div>
    </div>

    <!-- Filters Section -->
    <div class="lm-filter-card">
        <form method="GET" action="<?php echo e(route('admin.leave.index')); ?>" id="filterForm">
            <div class="row g-3 align-items-end">
                <div class="col-md-2">
                    <label class="lm-filter-label">Date Filter</label>
                    <select name="date_filter_type" id="dateFilterType" class="lm-filter-select">
                        <option value="year" <?php echo e(request('date_filter_type') == 'year' ? 'selected' : ''); ?>>Yearly</option>
                        <option value="month" <?php echo e(request('date_filter_type') == 'month' ? 'selected' : ''); ?>>Monthly</option>
                        <option value="custom" <?php echo e(request('date_filter_type') == 'custom' ? 'selected' : ''); ?>>Custom Range</option>
                    </select>
                </div>

                <div class="col-md-2" id="yearDiv">
                    <label class="lm-filter-label">Year</label>
                    <select name="year" class="lm-filter-select">
                        <?php for($y = date('Y'); $y >= date('Y')-3; $y--): ?>
                            <option value="<?php echo e($y); ?>" <?php echo e(request('year', date('Y')) == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="col-md-2" id="monthDiv" style="display: none;">
                    <label class="lm-filter-label">Month</label>
                    <select name="month" class="lm-filter-select">
                        <?php for($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo e(sprintf('%02d', $m)); ?>" <?php echo e(request('month', date('m')) == sprintf('%02d', $m) ? 'selected' : ''); ?>>
                                <?php echo e(date('F', mktime(0,0,0,$m,1))); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="col-md-2" id="startDiv" style="display: none;">
                    <label class="lm-filter-label">Start Date</label>
                    <input type="date" name="start_date" class="lm-filter-input" value="<?php echo e(request('start_date')); ?>">
                </div>
                <div class="col-md-2" id="endDiv" style="display: none;">
                    <label class="lm-filter-label">End Date</label>
                    <input type="date" name="end_date" class="lm-filter-input" value="<?php echo e(request('end_date')); ?>">
                </div>

                <div class="col-md-2">
                    <label class="lm-filter-label">Department</label>
                    <select name="department_id" class="lm-filter-select">
                        <option value="">All Departments</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dept->id); ?>" <?php echo e(request('department_id') == $dept->id ? 'selected' : ''); ?>><?php echo e($dept->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="col-md-2">
                    <label class="lm-filter-label">Employee</label>
                    <select name="employee_id" class="lm-filter-select">
                        <option value="">All Employees</option>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($emp->id); ?>" <?php echo e(request('employee_id') == $emp->id ? 'selected' : ''); ?>><?php echo e($emp->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="lm-filter-label">Status</label>
                    <select name="status" class="lm-filter-select">
                        <option value="">All Status</option>
                        <option value="Pending" <?php echo e(request('status') == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="Approved" <?php echo e(request('status') == 'Approved' ? 'selected' : ''); ?>>Approved</option>
                        <option value="Rejected" <?php echo e(request('status') == 'Rejected' ? 'selected' : ''); ?>>Rejected</option>
                    </select>
                </div>

                <div class="col-md-12 d-flex justify-content-end gap-2 mt-4 pt-2 border-top">
                    <?php if(request()->anyFilled(['date_filter_type', 'department_id', 'employee_id', 'status', 'clear_filters'])): ?>
                        <a href="<?php echo e(route('admin.leave.index', ['clear_filters' => 1])); ?>" class="btn-outline-custom text-decoration-none">Clear</a>
                    <?php endif; ?>
                    <button type="button" class="btn-outline-custom" onclick="exportExcel()"><i class="fa-solid fa-file-excel me-2"></i>Export to Excel</button>
                    <button type="submit" class="btn-primary-custom">Apply Filters</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Table Section -->
    <div class="lm-table-card">
        <div class="lm-table-header">Leave Requests</div>
        <?php if($leaves->isEmpty()): ?>
            <div class="text-center py-5">
                <i class="fa-regular fa-folder-open text-muted mb-3" style="font-size: 2.5rem;"></i>
                <h6 class="fw-bold text-dark">No records found</h6>
                <p class="text-muted small">Try adjusting your filters.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="lm-table">
                    <thead>
                        <tr>
                            <th>Employee</th>
                            <th>Duration</th>
                            <th>Days</th>
                            <th>Status</th>
                            <th>Reason</th>
                            <th>Applied On</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="fw-bold text-dark" style="font-size: 0.9rem;"><?php echo e($leave->employee->name ?? 'Unknown'); ?></div>
                                    <div class="text-muted" style="font-size: 0.75rem;"><?php echo e($leave->employee->employee_id ?? ''); ?> • <?php echo e($leave->employee->departmentRel->name ?? 'General'); ?></div>
                                </td>
                                <td>
                                    <div class="fw-medium text-dark"><?php echo e(\Carbon\Carbon::parse($leave->start_date)->format('M d, Y')); ?></div>
                                    <div class="text-muted" style="font-size: 0.75rem;">to <?php echo e(\Carbon\Carbon::parse($leave->end_date)->format('M d, Y')); ?></div>
                                </td>
                                <td class="fw-bold text-dark"><?php echo e($leave->total_days); ?></td>
                                <td>
                                    <?php
                                        $pillClass = match($leave->status) {
                                            'Approved' => 'pill-approved',
                                            'Rejected' => 'pill-rejected',
                                            default => 'pill-pending'
                                        };
                                    ?>
                                    <span class="status-pill <?php echo e($pillClass); ?>"><?php echo e($leave->status); ?></span>
                                </td>
                                <td>
                                    <div class="text-truncate" style="max-width: 200px;" title="<?php echo e($leave->reason); ?>">
                                        <?php echo e($leave->reason ?: '—'); ?>

                                    </div>
                                </td>
                                <td class="text-muted"><?php echo e($leave->created_at->format('M d, Y')); ?></td>
                                <td class="text-end whitespace-nowrap">
                                    <?php if($leave->status == 'Pending'): ?>
                                        <form action="<?php echo e(route('admin.leave.approve', $leave->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn-action btn-approve"><i class="fa-solid fa-check"></i> Approve</button>
                                        </form>
                                        <form action="<?php echo e(route('admin.leave.reject', $leave->id)); ?>" method="POST" class="d-inline ms-1">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn-action btn-reject"><i class="fa-solid fa-xmark"></i> Reject</button>
                                        </form>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('admin.leave.destroy', $leave->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this record?');">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="btn-action bg-light text-secondary border"><i class="fa-solid fa-trash-can"></i></button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    function toggleDateInputs() {
        const type = document.getElementById('dateFilterType').value;
        document.getElementById('yearDiv').style.display = (type === 'year' || type === 'month') ? 'block' : 'none';
        document.getElementById('monthDiv').style.display = (type === 'month') ? 'block' : 'none';
        document.getElementById('startDiv').style.display = (type === 'custom') ? 'block' : 'none';
        document.getElementById('endDiv').style.display = (type === 'custom') ? 'block' : 'none';
    }

    document.getElementById('dateFilterType').addEventListener('change', toggleDateInputs);
    // Init on load
    toggleDateInputs();

    function exportExcel() {
        // Change form action to export route, submit, then change it back
        const form = document.getElementById('filterForm');
        const originalAction = form.action;
        form.action = "<?php echo e(route('admin.leave.export')); ?>";
        form.submit();
        form.action = originalAction;
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\SMEClLABS\Documents\projects\2026\july\smec-eims\resources\views/admin/leave/index.blade.php ENDPATH**/ ?>