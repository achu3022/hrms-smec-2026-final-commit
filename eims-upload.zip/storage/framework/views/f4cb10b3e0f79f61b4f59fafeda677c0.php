<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'HRMS Admin')); ?></title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- DataTables -->
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        :root {
            --brand-primary: #4f46e5; /* Indigo 600 */
            --brand-dark: #1e293b; /* Slate 800 */
            --brand-sidebar: #2b3a67;
            --light-bg: #f8fafb;
            --sidebar-width: 260px;
        }
        
        body { 
            background: #f0f4f8;
            overflow-x: hidden;
            font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar { 
            min-height: 100vh;
            background: var(--brand-sidebar);
            color: #e2e8f0;
            transition: all 0.3s;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
        }
        
        .sidebar-header {
            padding: 25px 20px !important;
            background: rgba(0,0,0,0.1);
            border-bottom: 1px solid rgba(255,255,255,0.05) !important;
            position: relative;
            z-index: 1;
            text-align: center;
        }
        
        .sidebar-header h4 {
            margin: 0;
            font-weight: 700;
            font-size: 1.4rem;
            color: #ffffff;
        }
        
        .sidebar a { 
            color: #cbd5e1;
            text-decoration: none;
            padding: 14px 20px;
            display: flex;
            align-items: center;
            border-left: 4px solid transparent;
            transition: all 0.2s ease;
            position: relative;
            z-index: 1;
            font-weight: 500;
            margin: 4px 12px;
            border-radius: 8px;
        }
        
        .sidebar a i {
            width: 24px;
            margin-right: 12px;
            font-size: 1.1rem;
        }
        
        .sidebar a:hover { 
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
        }
        
        .sidebar a.active { 
            background: rgba(255, 255, 255, 0.15);
            color: #ffffff;
            font-weight: 600;
        }
        
        .content { 
            width: 100%;
            transition: all 0.3s;
            min-height: 100vh;
        }
        
        .topbar { 
            background: white;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
            padding: 15px 30px;
            border-bottom: 1px solid #e2e8f0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .topbar .btn {
            border: 1px solid #e2e8f0;
            color: var(--brand-dark);
            border-radius: 8px;
            padding: 8px 16px;
            font-weight: 600;
            transition: all 0.2s;
        }
        
        .topbar .btn:hover {
            background: #f1f5f9;
            color: var(--brand-dark);
        }
        
        .user-info {
            color: var(--brand-dark);
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .wrapper { 
            display: flex;
            align-items: stretch;
        }
        
        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            transition: all 0.3s;
            overflow: hidden;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--brand-teal), var(--brand-blue));
            color: white;
            font-weight: 600;
            border: none;
            padding: 18px 24px;
        }
        
        .btn-primary {
            background: var(--brand-primary);
            border: none;
            border-radius: 8px;
            padding: 10px 24px;
            font-weight: 600;
            transition: all 0.3s;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: #4338ca; /* Indigo 700 */
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
            color: #ffffff;
        }
        
        .btn-success {
            background: #10b981; /* Emerald 500 */
            border: none;
            border-radius: 8px;
            padding: 10px 24px;
            font-weight: 600;
            color: #ffffff;
            transition: all 0.3s;
        }
        
        .btn-success:hover {
            background: #059669; /* Emerald 600 */
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
            color: #ffffff;
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .alert-success {
            background: linear-gradient(135deg, #d4edda, #c3e6cb);
            color: #155724;
        }
        
        .alert-danger {
            background: linear-gradient(135deg, #f8d7da, #f5c6cb);
            color: #721c24;
        }
        
        /* Mobile Sidebar Styles */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0,0,0,0.5);
            z-index: 1040;
        }
        @media (max-width: 768px) {
            .sidebar {
                position: fixed !important;
                z-index: 1050;
                left: -260px;
                height: 100vh;
                transition: left 0.3s ease;
            }
            .sidebar.active {
                left: 0;
            }
            .sidebar-overlay.active {
                display: block;
            }
        }
        @media (min-width: 769px) {
            .sidebar.collapsed {
                margin-left: -260px;
            }
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<div class="wrapper">
    <div class="sidebar-overlay"></div>
    <!-- Sidebar -->
    <nav class="sidebar" style="min-width: 260px; max-width: 260px;">
        <div class="sidebar-header">
            <img src="<?php echo e(asset('smec-white.png')); ?>" alt="Logo" style="max-width: 180px; height: auto;" class="mb-2">
            <div class="mt-2">
                <small class="text-muted fw-bold">Admin Dashboard</small>
            </div>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                    <i class="fa fa-dashboard"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.employees.index')); ?>" class="<?php echo e(request()->routeIs('admin.employees.*') ? 'active' : ''); ?>">
                    <i class="fa fa-users"></i> Employees
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.organization.index', 'departments')); ?>" class="<?php echo e(request()->is('admin/organization/departments*') ? 'active' : ''); ?>">
                    <i class="fa fa-building"></i> Departments
                </a>
            </li>
            <!-- Designations Hidden 
            <li>
                <a href="<?php echo e(route('admin.organization.index', 'designations')); ?>" class="<?php echo e(request()->is('admin/organization/designations*') ? 'active' : ''); ?>">
                    <i class="fa fa-id-badge"></i> Designations
                </a>
            </li>
            -->
            <li>
                <a href="<?php echo e(route('admin.organization.index', 'branches')); ?>" class="<?php echo e(request()->is('admin/organization/branches*') ? 'active' : ''); ?>">
                    <i class="fa fa-map-marker-alt"></i> Branches
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.leave.index')); ?>" class="<?php echo e(request()->routeIs('admin.leave.*') ? 'active' : ''); ?>">
                    <i class="fa fa-calendar-alt"></i> Leave Requests
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.attendance.index')); ?>" class="<?php echo e(request()->routeIs('admin.attendance.*') ? 'active' : ''); ?>">
                    <i class="fa fa-clock"></i> Attendance
                </a>
            </li>
            <!--
            <li>
                <a href="<?php echo e(route('admin.assets.index')); ?>" class="<?php echo e(request()->routeIs('admin.assets.*') ? 'active' : ''); ?>">
                    <i class="fa fa-laptop"></i> Assets
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.api-tokens.index')); ?>" class="<?php echo e(request()->routeIs('admin.api-tokens.*') ? 'active' : ''); ?>">
                    <i class="fa fa-key"></i> API Tokens
                </a>
            </li>
            -->
            <li>
                <form method="POST" action="<?php echo e(route('logout')); ?>" id="logout-form">
                    <?php echo csrf_field(); ?>
                    <a href="#" onclick="document.getElementById('logout-form').submit();">
                        <i class="fa fa-sign-out"></i> Logout
                    </a>
                </form>
            </li>
        </ul>
    </nav>

    <!-- Page Content -->
    <div class="content">
        <div class="topbar d-flex justify-content-between align-items-center">
            <button class="btn" id="sidebarCollapse">
                <i class="fa fa-bars"></i> <span class="d-none d-md-inline">Menu</span>
            </button>
            <div class="user-info">
                <i class="fa fa-user-circle me-2"></i>
                <span><?php echo e(Auth::user()->name); ?></span>
            </div>
        </div>

        <div class="container-fluid p-4">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>

<!-- jQuery & Bootstrap -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
<script>
    $('#sidebarCollapse').on('click', function () {
        if ($(window).width() <= 768) {
            $('.sidebar').toggleClass('active');
            $('.sidebar-overlay').toggleClass('active');
        } else {
            $('.sidebar').toggleClass('collapsed');
        }
    });

    $('.sidebar-overlay').on('click', function() {
        $('.sidebar').removeClass('active');
        $(this).removeClass('active');
    });
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\SMEClLABS\Documents\projects\2026\july\smec-eims\resources\views/layouts/admin.blade.php ENDPATH**/ ?>