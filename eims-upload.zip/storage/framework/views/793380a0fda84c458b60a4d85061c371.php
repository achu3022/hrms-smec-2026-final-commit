<?php $__env->startSection('content'); ?>

<?php
    $attendanceState = 'unpunched';
    $punchInTime = null;
    $punchOutTime = null;
    $totalWorkHoursStr = null;
    $isHalfDay = false;

    if ($todayAttendance) {
        if ($todayAttendance->check_in && !$todayAttendance->check_out) {
            $attendanceState = 'punched_in';
            $punchInTime = \Carbon\Carbon::parse($todayAttendance->check_in)->format('h:i A');
        } elseif ($todayAttendance->check_in && $todayAttendance->check_out) {
            $attendanceState = 'punched_out';
            $punchInTime = \Carbon\Carbon::parse($todayAttendance->check_in)->format('h:i A');
            $punchOutTime = \Carbon\Carbon::parse($todayAttendance->check_out)->format('h:i A');
            
            $checkIn = \Carbon\Carbon::parse($todayAttendance->check_in);
            $checkOut = \Carbon\Carbon::parse($todayAttendance->check_out);
            $diffInMinutes = $checkIn->diffInMinutes($checkOut);
            $hours = floor($diffInMinutes / 60);
            $minutes = $diffInMinutes % 60;
            $totalWorkHoursStr = "{$hours}h {$minutes}m";
        }
        
        if ($todayAttendance->status === 'Half-Day' || $todayAttendance->status === 'Late') {
            $isHalfDay = true;
        }
    }
?>

<?php $__env->startPush('styles'); ?>
<style>
    /* ── Celebrations ───────────────────────────────── */
    .ep-celebrations-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
    }
    .ep-celebration-tabs {
        display: flex;
        gap: 6px;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        padding: 3px;
        border-radius: 10px;
    }
    .ep-celebration-tab-btn {
        background: none;
        border: none;
        font-size: 0.75rem;
        font-weight: 700;
        color: #94a3b8;
        padding: 5px 12px;
        border-radius: 7px;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    .ep-celebration-tab-btn.active {
        color: #4f46e5;
        background: #fff;
        box-shadow: 0 1px 4px rgba(0,0,0,0.08);
    }
    .ep-celebration-list { display: flex; flex-direction: column; gap: 10px; }
    .ep-celebration-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 14px;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        transition: all 0.2s ease;
    }
    .ep-celebration-item:hover { background:#fff; box-shadow:0 2px 8px rgba(0,0,0,0.05); }
    .ep-celebration-profile { display:flex; align-items:center; gap:10px; }
    .ep-celebration-avatar {
        width: 36px; height: 36px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-weight: 700; font-size: 0.85rem;
    }
    .ep-celebration-info { display:flex; flex-direction:column; }
    .ep-celebration-name { font-size:0.85rem; font-weight:700; color:#1e293b; }
    .ep-celebration-sub  { font-size:0.72rem; color:#94a3b8; }
    .ep-badge {
        font-size: 0.7rem; font-weight: 700;
        padding: 3px 9px; border-radius: 7px;
        display: flex; align-items: center; gap: 4px;
    }
    .ep-badge.birthday    { background:#fff5f5; color:#e03131; }
    .ep-badge.anniversary { background:#e6fcf5; color:#0ca678; }

    /* ── Calendar ───────────────────────────────────── */
    .ep-calendar-day-cell {
        aspect-ratio: 1;
        display: flex; flex-direction: column;
        align-items: center; justify-content: center;
        border-radius: 50%;
        font-size: 0.8rem; font-weight: 600;
        cursor: pointer; position: relative;
        transition: all 0.2s ease;
        color: #475569;
    }
    .ep-calendar-day-cell:hover   { background-color: #f1f5f9; }
    .ep-calendar-day-cell.other-month { color: #cbd5e1; pointer-events:none; }
    .ep-calendar-day-cell.today   { border: 2px solid #2b3a67; }
    .ep-calendar-day-cell.has-holiday  { background:#fff5f5!important; color:#e03131!important; border:1px solid #ffc9c9; }
    .ep-calendar-day-cell.has-birthday { background:#fff9db!important; color:#f08c00!important; border:1px solid #ffe066; }
    .ep-calendar-day-cell.has-anniversary { background:#ebfbee!important; color:#2b8a3e!important; border:1px solid #b2f2bb; }
    .ep-legend-dot { display:inline-block; width:7px; height:7px; border-radius:50%; }

    /* ── Popover ────────────────────────────────────── */
    .ep-cal-popover {
        position: absolute;
        width: 260px; background:#fff;
        border-radius: 14px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.12);
        border: 1px solid #e2e8f0;
        z-index: 100; padding: 14px;
        display: none; box-sizing: border-box;
    }
    .ep-popover-header {
        display: flex; justify-content:space-between; align-items:center;
        border-bottom: 1px solid #f1f5f9;
        padding-bottom: 8px; margin-bottom: 10px;
    }
    .ep-popover-body { max-height: 160px; overflow-y:auto; }
    .ep-event-item {
        display:flex; align-items:center; justify-content:space-between;
        padding: 8px 10px; border-radius:10px;
        background:#f8fafc; border:1px solid #f1f5f9;
        margin-bottom: 6px;
    }
    .ep-event-item:last-child { margin-bottom:0; }
    .ep-event-left  { display:flex; align-items:center; gap:8px; min-width:0; }
    .ep-event-icon  {
        width:26px; height:26px; border-radius:50%;
        display:flex; align-items:center; justify-content:center; font-size:0.75rem;
    }
    .ep-event-info  { display:flex; flex-direction:column; min-width:0; }
    .ep-event-title { font-size:0.75rem; font-weight:700; color:#1e293b; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .ep-event-sub   { font-size:0.65rem; color:#94a3b8; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .ep-event-badge { font-size:0.65rem; font-weight:700; padding:2px 7px; border-radius:5px; }
</style>
<?php $__env->stopPush(); ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

    <!-- Column 1 -->
    <div class="space-y-6">
        
        <!-- Attendance Widget -->
        <div class="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
            <div class="bg-slate-50 px-5 py-4 border-b border-slate-100 flex items-center gap-2">
                <i class="fa-solid fa-clock text-rose-500 text-lg"></i>
                <div>
                    <h3 class="font-bold text-slate-800 leading-tight">Attendance</h3>
                    <p class="text-xs text-slate-500">Punch in/out for today</p>
                </div>
            </div>
            
            <div class="p-5">
                
                <?php if($attendanceState === 'unpunched'): ?>
                    <!-- Unpunched State -->
                    <div class="text-center py-4" id="unpunched-view">
                        <div class="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                            <i class="fa-regular fa-clock"></i>
                        </div>
                        <p class="text-slate-600 text-sm mb-4">You haven't punched in today</p>
                        
                        <p class="text-xs font-semibold text-slate-700 mb-2">Punch Machine Time</p>
                        <div class="border border-slate-200 rounded-lg py-3 px-4 mb-2 flex justify-between items-center bg-white shadow-inner">
                            <span class="font-mono text-lg tracking-wider font-semibold text-slate-800" id="live-clock">--:--:--</span>
                            <i class="fa-regular fa-clock text-slate-400"></i>
                        </div>
                        <p class="text-xs text-slate-400 mb-6">Location access is required to punch in</p>
                        
                        <button onclick="handlePunch('in')" id="punchInBtn" class="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-4 rounded-lg shadow-md transition flex justify-center items-center gap-2">
                            <i class="fa-solid fa-right-to-bracket"></i> Punch In
                        </button>
                    </div>
                <?php endif; ?>
                
                <div id="punched-view" class="<?php echo e($attendanceState === 'unpunched' ? 'hidden' : ''); ?>">
                    <!-- Status Cards -->
                    <div class="space-y-3 mb-5">
                        <!-- Punched In Card -->
                        <div class="border border-emerald-200 bg-emerald-50 rounded-lg p-3 flex justify-between items-center" id="card-punched-in" style="display: <?php echo e($attendanceState !== 'unpunched' ? 'flex' : 'none'); ?>">
                            <div class="flex items-center gap-3">
                                <div class="w-8 h-8 bg-emerald-500 text-white rounded-full flex items-center justify-center">
                                    <i class="fa-solid fa-check"></i>
                                </div>
                                <div>
                                    <p class="text-sm font-bold text-emerald-800 leading-tight">Punched In</p>
                                    <p class="text-xs text-emerald-600" id="txt-punch-in"><?php echo e($punchInTime ?? '--:--'); ?></p>
                                </div>
                            </div>
                            <span class="bg-emerald-500 text-white text-xs px-2 py-0.5 rounded-full font-semibold">Active</span>
                        </div>

                        <!-- Half Day Warning (if applicable) -->
                        <?php if($isHalfDay): ?>
                        <div class="border border-orange-200 bg-orange-50 rounded-lg p-3">
                            <div class="flex items-start gap-2">
                                <i class="fa-solid fa-triangle-exclamation text-orange-500 mt-0.5"></i>
                                <div>
                                    <p class="text-sm font-bold text-orange-800 leading-tight">Marked as Half Day / Late</p>
                                    <p class="text-xs text-orange-700 mt-1">Punch time after allowed grace period.</p>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Punched Out Card -->
                        <div class="border border-red-200 bg-red-50 rounded-lg p-3 flex justify-between items-center" id="card-punched-out" style="display: <?php echo e($attendanceState === 'punched_out' ? 'flex' : 'none'); ?>">
                            <div class="flex items-center gap-3">
                                <div class="w-8 h-8 bg-red-500 text-white rounded-full flex items-center justify-center">
                                    <i class="fa-solid fa-right-from-bracket"></i>
                                </div>
                                <div>
                                    <p class="text-sm font-bold text-red-800 leading-tight">Punched Out</p>
                                    <p class="text-xs text-red-600" id="txt-punch-out"><?php echo e($punchOutTime ?? '--:--'); ?></p>
                                </div>
                            </div>
                            <span class="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full font-semibold">Completed</span>
                        </div>

                        <!-- Working Time / Total Hours -->
                        <div class="border border-blue-200 bg-blue-50 rounded-lg p-4 text-center" id="card-working-time">
                            <p class="text-xs font-bold text-blue-800 mb-1" id="lbl-working-time">
                                <?php echo e($attendanceState === 'punched_out' ? 'Total Work Hours' : 'Working Time'); ?>

                            </p>
                            <p class="text-2xl font-bold text-blue-600 font-mono tracking-wider" id="val-working-time">
                                <?php echo e($attendanceState === 'punched_out' ? $totalWorkHoursStr : '00:00:00'); ?>

                            </p>
                        </div>
                    </div>

                    <?php if($attendanceState !== 'punched_out'): ?>
                        <button onclick="handlePunch('out')" id="punchOutBtn" class="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-4 rounded-lg shadow-md transition flex justify-center items-center gap-2">
                            <i class="fa-solid fa-right-from-bracket"></i> Punch Out
                        </button>
                    <?php endif; ?>
                </div>

            </div>
        </div>



    </div>

    <!-- Column 2 -->
    <div class="space-y-6">
        


        <!-- Upcoming Celebrations (DB-driven) -->
        <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-5">
            <div class="ep-celebrations-header">
                <h3 class="font-bold text-slate-800 text-sm">Upcoming Celebrations</h3>
                <div class="ep-celebration-tabs">
                    <button id="epBtnBdays" class="ep-celebration-tab-btn active" onclick="epSwitchCeleb('birthdays')">Birthdays</button>
                    <button id="epBtnAnnivs" class="ep-celebration-tab-btn" onclick="epSwitchCeleb('anniversaries')">Anniversaries</button>
                </div>
            </div>

            <!-- Birthdays -->
            <div id="epCelebBirthdays" class="ep-celebration-list">
                <?php $__empty_1 = true; $__currentLoopData = $upcomingBirthdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $initials = collect(explode(' ', $emp->name))->map(fn($n)=>mb_substr($n,0,1))->take(2)->join(''); ?>
                    <div class="ep-celebration-item">
                        <div class="ep-celebration-profile">
                            <div class="ep-celebration-avatar" style="background:#fff0f6;color:#d6336c;"><?php echo e($initials); ?></div>
                            <div class="ep-celebration-info">
                                <span class="ep-celebration-name"><?php echo e($emp->name); ?></span>
                                <span class="ep-celebration-sub"><?php echo e($emp->designationRel->name ?? $emp->designation ?? 'Staff'); ?> &bull; <?php echo e($emp->departmentRel->name ?? $emp->department ?? 'General'); ?></span>
                            </div>
                        </div>
                        <span class="ep-badge birthday"><i class="fa-solid fa-cake-candles"></i> <?php echo e(\Carbon\Carbon::parse($emp->dob)->format('M d')); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-xs text-slate-400 text-center py-4">No birthdays in the next 7 days.</p>
                <?php endif; ?>
            </div>

            <!-- Anniversaries -->
            <div id="epCelebAnnivs" class="ep-celebration-list" style="display:none;">
                <?php $__empty_1 = true; $__currentLoopData = $workAnniversaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $initials = collect(explode(' ', $emp->name))->map(fn($n)=>mb_substr($n,0,1))->take(2)->join('');
                        $years = $emp->anniversary_years;
                    ?>
                    <div class="ep-celebration-item">
                        <div class="ep-celebration-profile">
                            <div class="ep-celebration-avatar" style="background:#e6fcf5;color:#0ca678;"><?php echo e($initials); ?></div>
                            <div class="ep-celebration-info">
                                <span class="ep-celebration-name"><?php echo e($emp->name); ?></span>
                                <span class="ep-celebration-sub">Joined <?php echo e(\Carbon\Carbon::parse($emp->joining_date)->format('M d, Y')); ?></span>
                            </div>
                        </div>
                        <span class="ep-badge anniversary"><i class="fa-solid fa-award"></i> <?php echo e($years > 0 ? $years.' Yr'.($years>1?'s':'') : 'New'); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-xs text-slate-400 text-center py-4">No anniversaries in the next 7 days.</p>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- Column 3: Events Calendar -->
    <div class="space-y-6">
        <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-5" style="position:relative;">
            <!-- Header -->
            <div class="flex justify-between items-center mb-3 pb-2 border-b border-slate-100">
                <h3 class="font-bold text-slate-800 text-sm"><i class="fa-solid fa-calendar-days text-indigo-500 mr-1"></i> Events Calendar</h3>
                <div class="flex gap-1 items-center">
                    <button onclick="epPrevMonth()" class="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs flex items-center justify-center transition">
                        <i class="fa-solid fa-chevron-left"></i>
                    </button>
                    <span id="epCalMonthYear" class="font-bold text-slate-700 text-xs min-w-[88px] text-center"></span>
                    <button onclick="epNextMonth()" class="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs flex items-center justify-center transition">
                        <i class="fa-solid fa-chevron-right"></i>
                    </button>
                </div>
            </div>

            <!-- Weekday headers -->
            <div class="grid grid-cols-7 text-center text-slate-400 font-bold mb-1" style="font-size:0.7rem;letter-spacing:0.5px;">
                <span>S</span><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span>
            </div>

            <!-- Day grid -->
            <div id="epCalGrid" class="grid grid-cols-7 text-center gap-1 mb-3">
                <!-- injected by JS -->
            </div>

            <!-- Legend -->
            <div class="flex justify-center gap-4 pt-2 border-t border-slate-100" style="font-size:0.68rem;font-weight:600;color:#64748b;">
                <span class="flex items-center gap-1"><span class="ep-legend-dot" style="background:#f08c00;"></span>Birthday</span>
                <span class="flex items-center gap-1"><span class="ep-legend-dot" style="background:#2b8a3e;"></span>Anniversary</span>
                <span class="flex items-center gap-1"><span class="ep-legend-dot" style="background:#e03131;"></span>Holiday</span>
            </div>

            <!-- Popover -->
            <div id="epCalPopover" class="ep-cal-popover" style="display:none;">
                <div class="ep-popover-header">
                    <span id="epPopoverTitle" style="font-size:0.8rem;font-weight:700;color:#1e293b;">Events</span>
                    <button onclick="epClosePopover()" style="background:none;border:none;font-size:1.1rem;color:#94a3b8;cursor:pointer;">&times;</button>
                </div>
                <div id="epPopoverBody" class="ep-popover-body"></div>
            </div>
        </div>
    </div>


</div>

<?php $__env->startPush('scripts'); ?>
<script>
    // ── Internet Time Sync (Asia/Kolkata via worldtimeapi.org) ──────────────
    let internetNow = null; // will hold a Date object synced from the internet
    let syncedAt   = null; // performance.now() at the moment of sync

    function getInternetNow() {
        if (!internetNow) return null;
        const elapsedMs = performance.now() - syncedAt;
        return new Date(internetNow.getTime() + elapsedMs);
    }

    function syncInternetTime(callback) {
        fetch('https://worldtimeapi.org/api/timezone/Asia/Kolkata')
            .then(r => r.json())
            .then(data => {
                internetNow = new Date(data.datetime);
                syncedAt    = performance.now();
                if (callback) callback();
            })
            .catch(() => {
                // Fallback to device time if API fails
                internetNow = new Date();
                syncedAt    = performance.now();
                if (callback) callback();
            });
    }

    // Live Clock for Punch Machine Time
    function updateClock() {
        const now = getInternetNow();
        if (!now) return;
        let hours   = now.getHours();
        let minutes = now.getMinutes();
        let seconds = now.getSeconds();
        const ampm  = hours >= 12 ? 'PM' : 'AM';
        hours   = hours % 12 || 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        seconds = seconds < 10 ? '0' + seconds : seconds;
        const strTime = hours + ':' + minutes + ':' + seconds + ' ' + ampm;

        const clockEl = document.getElementById('live-clock');
        if (clockEl) clockEl.innerText = strTime;
    }

    // Start clock after first sync
    syncInternetTime(() => {
        setInterval(updateClock, 1000);
        updateClock();
    });

    // Re-sync every 10 minutes to correct any drift
    setInterval(() => syncInternetTime(), 10 * 60 * 1000);

    // Working Time counter logic (if punched in but not out)
    <?php if($attendanceState === 'punched_in'): ?>
        const punchInTimeString = "<?php echo e($todayAttendance->check_in ?? ''); ?>";
        if (punchInTimeString) {
            // Build punch-in Date in Asia/Kolkata context using today's date
            const punchInDate = (() => {
                const d = new Date();
                const [h, m, s] = punchInTimeString.split(':');
                return new Date(d.getFullYear(), d.getMonth(), d.getDate(),
                                parseInt(h), parseInt(m), parseInt(s || 0));
            })();

            function updateWorkingTime() {
                const now  = getInternetNow();
                if (!now) return;
                let diff = Math.floor((now - punchInDate) / 1000);
                if (diff < 0) diff = 0;

                const h = Math.floor(diff / 3600).toString().padStart(2, '0');
                const m = Math.floor((diff % 3600) / 60).toString().padStart(2, '0');
                const s = (diff % 60).toString().padStart(2, '0');

                document.getElementById('val-working-time').innerText = `${h}:${m}:${s}`;
            }
            setInterval(updateWorkingTime, 1000);
            updateWorkingTime();
        }
    <?php endif; ?>


    function handlePunch(type) {
        if (!navigator.geolocation) {
            alert('Geolocation is not supported by your browser. Cannot punch in/out.');
            return;
        }

        const btnId = type === 'in' ? 'punchInBtn' : 'punchOutBtn';
        const btn = document.getElementById(btnId);
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Getting Location...';
        btn.disabled = true;

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                submitPunch(type, lat, lng, btn, originalText);
            },
            (error) => {
                alert('Location access denied. You must allow location to mark attendance.');
                btn.innerHTML = originalText;
                btn.disabled = false;
            },
            { enableHighAccuracy: true, timeout: 10000 }
        );
    }

    function submitPunch(type, lat, lng, btn, originalText) {
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
        
        const url = type === 'in' ? "<?php echo e(route('employee.attendance.punch-in')); ?>" : "<?php echo e(route('employee.attendance.punch-out')); ?>";
        
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({ latitude: lat, longitude: lng })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload(); // Reload to show updated state
            } else {
                alert(data.message || 'Error occurred.');
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        })
        .catch(err => {
            alert('Network error. Please try again.');
            btn.innerHTML = originalText;
            btn.disabled = false;
        });
    }
</script>

<script>
    // ── Celebrations Tab Switch ────────────────────────────────────────────
    function epSwitchCeleb(type) {
        const bdayEl  = document.getElementById('epCelebBirthdays');
        const annivEl = document.getElementById('epCelebAnnivs');
        const btnB    = document.getElementById('epBtnBdays');
        const btnA    = document.getElementById('epBtnAnnivs');
        if (type === 'birthdays') {
            bdayEl.style.display  = 'flex';
            annivEl.style.display = 'none';
            btnB.classList.add('active');
            btnA.classList.remove('active');
        } else {
            bdayEl.style.display  = 'none';
            annivEl.style.display = 'flex';
            btnB.classList.remove('active');
            btnA.classList.add('active');
        }
    }

    // ── Events Calendar ────────────────────────────────────────────────────
    const epEmployees = <?php echo json_encode($calendarEmployees, 15, 512) ?>;
    const epHolidays  = <?php echo json_encode($companyHolidays, 15, 512) ?>;

    let epCurrentDate = new Date();

    document.addEventListener('DOMContentLoaded', function () {
        epRenderCalendar();
    });

    function epRenderCalendar() {
        const year  = epCurrentDate.getFullYear();
        const month = epCurrentDate.getMonth();
        const monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];

        document.getElementById('epCalMonthYear').innerText = `${monthNames[month]} ${year}`;

        const grid = document.getElementById('epCalGrid');
        grid.innerHTML = '';

        const firstDayIndex = new Date(year, month, 1).getDay();
        const lastDay       = new Date(year, month + 1, 0).getDate();
        const prevLastDay   = new Date(year, month, 0).getDate();
        const totalCells    = 42;

        let dayCounter = 1, nextMonthCounter = 1;

        for (let i = 0; i < totalCells; i++) {
            const cell = document.createElement('div');

            if (i < firstDayIndex) {
                cell.className = 'ep-calendar-day-cell other-month';
                cell.innerText = prevLastDay - firstDayIndex + i + 1;
            } else if (dayCounter <= lastDay) {
                const currentDay = dayCounter;
                cell.className = 'ep-calendar-day-cell';
                cell.innerText = currentDay;

                // Mark today
                const today = new Date();
                if (today.getDate() === currentDay && today.getMonth() === month && today.getFullYear() === year) {
                    cell.classList.add('today');
                }

                // Gather events
                const dayEvents = epGetDayEvents(year, month, currentDay);
                if (dayEvents.length > 0) {
                    const hasHoliday     = dayEvents.some(e => e.type === 'holiday');
                    const hasBirthday    = dayEvents.some(e => e.type === 'birthday');
                    const hasAnniversary = dayEvents.some(e => e.type === 'anniversary');

                    if (hasHoliday)          cell.classList.add('has-holiday');
                    else if (hasBirthday)    cell.classList.add('has-birthday');
                    else if (hasAnniversary) cell.classList.add('has-anniversary');

                    cell.addEventListener('click', (event) => {
                        event.stopPropagation();
                        epOpenPopover(year, month, currentDay, dayEvents, cell);
                    });
                }
                dayCounter++;
            } else {
                cell.className = 'ep-calendar-day-cell other-month';
                cell.innerText = nextMonthCounter++;
            }
            grid.appendChild(cell);
        }
    }

    function epPrevMonth() {
        epClosePopover();
        epCurrentDate.setMonth(epCurrentDate.getMonth() - 1);
        epRenderCalendar();
    }

    function epNextMonth() {
        epClosePopover();
        epCurrentDate.setMonth(epCurrentDate.getMonth() + 1);
        epRenderCalendar();
    }

    function epGetDayEvents(year, month, day) {
        const events = [];
        const dateObj   = new Date(year, month, day);
        const dayOfWeek = dateObj.getDay();

        // Sundays are holidays
        if (dayOfWeek === 0) {
            events.push({ type:'holiday', title:'Sunday Holiday', subtitle:'Weekly Off-Day',
                icon:'fa-umbrella-beach', iconBg:'#fff5f5', iconColor:'#e03131', dateLabel:'Holiday' });
        }

        // Birthdays
        epEmployees.forEach(emp => {
            if (emp.dob) {
                const parts = emp.dob.split('-');
                if (parseInt(parts[1],10) - 1 === month && parseInt(parts[2],10) === day) {
                    events.push({ type:'birthday', title:`${emp.name} (Birthday)`, subtitle:`${emp.department} Dept`,
                        icon:'fa-cake-candles', iconBg:'#fff9db', iconColor:'#f08c00', dateLabel:'Birthday' });
                }
            }
        });

        // Anniversaries
        epEmployees.forEach(emp => {
            if (emp.joining_date) {
                const parts    = emp.joining_date.split('-');
                const joinYear = parseInt(parts[0],10);
                if (parseInt(parts[1],10) - 1 === month && parseInt(parts[2],10) === day) {
                    const yrs = year - joinYear;
                    events.push({ type:'anniversary', title:`${emp.name} (Anniversary)`, subtitle:`Joined ${joinYear} • ${emp.department}`,
                        icon:'fa-star', iconBg:'#ebfbee', iconColor:'#2b8a3e', dateLabel: yrs > 0 ? `${yrs} Yr${yrs>1?'s':''}` : 'Joined' });
                }
            }
        });

        // Company Holidays
        epHolidays.forEach(holiday => {
            const parts = holiday.date.split('-');
            if (parseInt(parts[1],10) - 1 === month && parseInt(parts[2],10) === day) {
                if (!events.some(e => e.title === holiday.name)) {
                    events.push({ type:'holiday', title:holiday.name, subtitle:'Company Holiday',
                        icon:'fa-umbrella-beach', iconBg:'#fff5f5', iconColor:'#e03131', dateLabel:'Holiday' });
                }
            }
        });

        return events;
    }

    function epOpenPopover(year, month, day, dayEvents, cellElement) {
        const monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];
        document.getElementById('epPopoverTitle').innerText = `Events on ${monthNames[month]} ${day}, ${year}`;

        const body = document.getElementById('epPopoverBody');
        body.innerHTML = '';

        dayEvents.forEach(evt => {
            let badgeStyle = '';
            if (evt.type === 'birthday')    badgeStyle = 'background:#fff9db;color:#f08c00;';
            else if (evt.type === 'anniversary') badgeStyle = 'background:#ebfbee;color:#2b8a3e;';
            else if (evt.type === 'holiday')     badgeStyle = 'background:#fff5f5;color:#e03131;';

            const item = document.createElement('div');
            item.className = 'ep-event-item';
            item.innerHTML = `
                <div class="ep-event-left">
                    <div class="ep-event-icon" style="background:${evt.iconBg};color:${evt.iconColor};">
                        <i class="fa ${evt.icon}"></i>
                    </div>
                    <div class="ep-event-info">
                        <span class="ep-event-title">${evt.title}</span>
                        <span class="ep-event-sub">${evt.subtitle}</span>
                    </div>
                </div>
                <span class="ep-event-badge" style="${badgeStyle}">${evt.dateLabel}</span>
            `;
            body.appendChild(item);
        });

        const popover = document.getElementById('epCalPopover');
        popover.style.display = 'block';
        popover.style.top  = '0px';
        popover.style.left = '0px';

        const card = cellElement.closest('.bg-white');
        if (card) {
            const cardRect    = card.getBoundingClientRect();
            const cellRect    = cellElement.getBoundingClientRect();
            const popoverRect = popover.getBoundingClientRect();

            let top  = cellRect.top - cardRect.top - popoverRect.height - 10;
            let left = cellRect.left - cardRect.left + (cellRect.width / 2) - (popoverRect.width / 2);

            if (left < 10) left = 10;
            if (left + popoverRect.width > cardRect.width - 10) left = cardRect.width - popoverRect.width - 10;
            if (top < 10) top = cellRect.bottom - cardRect.top + 10;

            popover.style.top  = top  + 'px';
            popover.style.left = left + 'px';
        }
    }

    function epClosePopover() {
        document.getElementById('epCalPopover').style.display = 'none';
    }

    document.addEventListener('click', function (event) {
        const popover = document.getElementById('epCalPopover');
        if (!popover) return;
        const isInside = popover.contains(event.target);
        const isCell   = event.target.closest('.ep-calendar-day-cell');
        if (!isInside && !isCell && popover.style.display === 'block') epClosePopover();
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('employee.portal.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\SMEClLABS\Documents\projects\2026\july\smec-eims\resources\views/employee/portal/dashboard.blade.php ENDPATH**/ ?>