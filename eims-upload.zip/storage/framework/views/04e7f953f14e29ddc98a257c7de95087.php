<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5>Edit Employee: <?php echo e($employee->name); ?></h5>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.employees.update', $employee->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <div class="row g-3">
                <div class="col-md-6">
                    <label>Full Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($employee->name); ?>" required>
                </div>
                <div class="col-md-6">
                    <label>Department (ID)</label>
                    <input type="text" name="department_id" class="form-control" value="<?php echo e($employee->department_id); ?>">
                </div>
                <div class="col-md-6">
                    <label>Designation (ID)</label>
                    <input type="text" name="designation_id" class="form-control" value="<?php echo e($employee->designation_id); ?>">
                </div>
                <div class="col-md-6">
                    <label>Status</label>
                    <select name="status" class="form-select">
                        <option value="Active" <?php echo e($employee->status == 'Active' ? 'selected' : ''); ?>>Active</option>
                        <option value="Inactive" <?php echo e($employee->status == 'Inactive' ? 'selected' : ''); ?>>Inactive</option>
                        <option value="Resigned" <?php echo e($employee->status == 'Resigned' ? 'selected' : ''); ?>>Resigned</option>
                        <option value="Terminated" <?php echo e($employee->status == 'Terminated' ? 'selected' : ''); ?>>Terminated</option>
                        <option value="On Leave" <?php echo e($employee->status == 'On Leave' ? 'selected' : ''); ?>>On Leave</option>
                    </select>
                </div>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary">Update Employee</button>
                <a href="<?php echo e(route('admin.employees.index')); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\SMEClLABS\Documents\projects\2026\july\smec-eims\resources\views/admin/employees/edit.blade.php ENDPATH**/ ?>