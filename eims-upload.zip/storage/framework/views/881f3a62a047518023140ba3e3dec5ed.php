<style>
    .modal-header-custom {
        background: linear-gradient(135deg, #00aa9e 0%, #0070bc 100%);
        color: white;
        padding: 40px 30px;
        position: relative;
    }
    .modal-close-btn {
        position: absolute;
        top: 20px;
        right: 20px;
        background: rgba(255,255,255,0.2);
        border: none;
        color: white;
        border-radius: 50%;
        width: 35px;
        height: 35px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s;
    }
    .modal-close-btn:hover {
        background: rgba(255,255,255,0.4);
    }
    .profile-img-container {
        position: absolute;
        bottom: -50px;
        left: 40px;
        padding: 4px;
        background: linear-gradient(135deg, #00aa9e, #0070bc);
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        z-index: 2;
    }
    .profile-img {
        width: 120px;
        height: 120px;
        border-radius: 8px;
        object-fit: cover;
        border: 4px solid white;
    }
    .profile-placeholder {
        width: 120px;
        height: 120px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #f8fafb, #e8f0f8);
        border: 4px solid white;
    }
    .profile-info {
        margin-left: 190px;
        min-height: 50px;
    }
    .custom-tabs {
        border-bottom: 2px solid #e8f4f8;
        padding-left: 30px;
    }
    .custom-tabs .nav-link {
        color: #666;
        font-weight: 600;
        border: none;
        border-bottom: 3px solid transparent;
        padding: 15px 25px;
        margin-bottom: -2px;
        transition: all 0.2s;
    }
    .custom-tabs .nav-link:hover {
        color: #00aa9e;
        background: #f8fafb;
    }
    .custom-tabs .nav-link.active {
        color: #00aa9e;
        border-bottom-color: #00aa9e;
        background: transparent;
    }
    .info-card {
        background: #ffffff;
        border-radius: 12px;
        padding: 25px;
        margin-bottom: 25px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.03);
        border: 1px solid #f0f4f8;
    }
    .info-card-title {
        color: #2f3092;
        font-weight: 700;
        margin-bottom: 20px;
        font-size: 1.1rem;
        display: flex;
        align-items: center;
    }
    .info-card-title i {
        color: #00aa9e;
        margin-right: 10px;
        font-size: 1.2rem;
    }
    .info-label {
        font-size: 0.8rem;
        color: #888;
        margin-bottom: 4px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 600;
    }
    .info-value {
        font-size: 1rem;
        color: #333;
        font-weight: 500;
        margin-bottom: 20px;
    }
    .badge-status {
        padding: 6px 12px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 0.85rem;
    }
    .modal-action-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 18px;
        border-radius: 8px;
        font-size: 0.85rem;
        font-weight: 600;
        border: none;
        cursor: pointer;
        transition: all 0.2s;
        text-decoration: none;
    }
    .modal-action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .btn-modal-email  { background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.4); }
    .btn-modal-email:hover  { background: white; color: #0070bc; }
    .btn-modal-edit   { background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.4); }
    .btn-modal-edit:hover   { background: white; color: #00aa9e; }
    .btn-modal-idcard { background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.4); }
    .btn-modal-idcard:hover { background: white; color: #2f3092; }
    .btn-modal-cert   { background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.4); }
    .btn-modal-cert:hover   { background: white; color: #6f42c1; }
    .btn-modal-delete { background: rgba(220,53,69,0.25); color: white; border: 1px solid rgba(220,53,69,0.5); }
    .btn-modal-delete:hover { background: #dc3545; color: white; }
</style>

<div class="modal-header-custom">
    <button type="button" class="modal-close-btn" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
    <div class="profile-img-container">
        <?php if($employee->photo): ?>
            <img src="<?php echo e(Storage::url($employee->photo)); ?>" class="profile-img">
        <?php else: ?>
            <div class="profile-placeholder">
                <i class="fa fa-user fa-4x text-secondary"></i>
            </div>
        <?php endif; ?>
    </div>
    <div class="profile-info">
        <h2 class="mb-1 fw-bold text-white"><?php echo e($employee->name); ?></h2>
        <p class="mb-3 fs-5 text-white-50"><i class="fa fa-id-badge me-2"></i><?php echo e($employee->employee_id); ?> &nbsp;|&nbsp; <i class="fa fa-briefcase me-2"></i><?php echo e($employee->designationRel->name ?? $employee->designation); ?></p>
        <div class="d-flex flex-wrap gap-2">
            <a href="mailto:<?php echo e($employee->company_email); ?>" class="modal-action-btn btn-modal-email">
                <i class="fa fa-envelope"></i> Email
            </a>
            <a href="<?php echo e(route('admin.employees.edit', $employee->id)); ?>" class="modal-action-btn btn-modal-edit">
                <i class="fa fa-edit"></i> Edit
            </a>
            
            <form action="<?php echo e(route('admin.employees.destroy', $employee->id)); ?>" method="POST" class="d-inline m-0" onsubmit="return confirm('Delete this employee?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="modal-action-btn btn-modal-delete">
                    <i class="fa fa-trash"></i> Delete
                </button>
            </form>
        </div>
    </div>
</div>

<div class="pt-5 mt-3 bg-light">
    <ul class="nav nav-tabs custom-tabs" id="employeeTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="overview-tab" data-bs-toggle="tab" data-bs-target="#overview" type="button" role="tab">Overview</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="docs-tab" data-bs-toggle="tab" data-bs-target="#docs" type="button" role="tab">Identity & Bank</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="edu-tab" data-bs-toggle="tab" data-bs-target="#edu" type="button" role="tab">Education & Experience</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="assets-tab" data-bs-toggle="tab" data-bs-target="#assets" type="button" role="tab">Assets</button>
        </li>
    </ul>

    <div class="tab-content p-4" id="employeeTabsContent">
        <!-- Overview Tab -->
        <div class="tab-pane fade show active" id="overview" role="tabpanel">
            <div class="row">
                <div class="col-md-6">
                    <div class="info-card">
                        <div class="info-card-title"><i class="fa fa-building"></i> Employment Details</div>
                        <div class="row">
                            <div class="col-sm-6"><div class="info-label">Department</div><div class="info-value"><?php echo e($employee->departmentRel->name ?? $employee->department); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Status</div><div class="info-value"><span class="badge <?php echo e($employee->status == 'Active' ? 'bg-success' : 'bg-danger'); ?> badge-status"><?php echo e($employee->status); ?></span></div></div>
                            <div class="col-sm-6"><div class="info-label">Joining Date</div><div class="info-value"><?php echo e($employee->joining_date ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Employment Type</div><div class="info-value"><?php echo e($employee->employment_type ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Reporting Manager</div><div class="info-value"><?php echo e($employee->reporting_manager ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Work Location</div><div class="info-value"><?php echo e($employee->work_location ?? 'N/A'); ?></div></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="info-card h-100">
                        <div class="info-card-title"><i class="fa fa-envelope"></i> Contact Information</div>
                        <div class="row">
                            <div class="col-sm-6"><div class="info-label">Company Email</div><div class="info-value"><?php echo e($employee->company_email ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Personal Email</div><div class="info-value"><?php echo e($employee->personal_email ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Office Phone</div><div class="info-value"><?php echo e($employee->office_phone ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Personal Phone</div><div class="info-value"><?php echo e($employee->personal_phone ?? 'N/A'); ?></div></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="info-card">
                        <div class="info-card-title"><i class="fa fa-user"></i> Personal Information</div>
                        <div class="row">
                            <div class="col-md-3 col-sm-6"><div class="info-label">DOB</div><div class="info-value"><?php echo e($employee->dob ?? 'N/A'); ?></div></div>
                            <div class="col-md-3 col-sm-6"><div class="info-label">Gender</div><div class="info-value"><?php echo e($employee->gender ?? 'N/A'); ?></div></div>
                            <div class="col-md-3 col-sm-6"><div class="info-label">Blood Group</div><div class="info-value"><?php echo e($employee->blood_group ?? 'N/A'); ?></div></div>
                            <div class="col-md-3 col-sm-6"><div class="info-label">Marital Status</div><div class="info-value"><?php echo e($employee->marital_status ?? 'N/A'); ?></div></div>
                            <div class="col-md-6"><div class="info-label">Present Address</div><div class="info-value"><?php echo e($employee->present_address ?? 'N/A'); ?></div></div>
                            <div class="col-md-6"><div class="info-label">Permanent Address</div><div class="info-value"><?php echo e($employee->permanent_address ?? 'N/A'); ?></div></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="info-card">
                        <div class="info-card-title"><i class="fa fa-heartbeat"></i> Emergency Contact</div>
                        <div class="row">
                            <div class="col-md-3 col-sm-6"><div class="info-label">Name</div><div class="info-value"><?php echo e($employee->emergency_name ?? 'N/A'); ?></div></div>
                            <div class="col-md-3 col-sm-6"><div class="info-label">Relation</div><div class="info-value"><?php echo e($employee->emergency_relation ?? 'N/A'); ?></div></div>
                            <div class="col-md-3 col-sm-6"><div class="info-label">Phone</div><div class="info-value"><?php echo e($employee->emergency_phone ?? 'N/A'); ?></div></div>
                            <div class="col-md-3 col-sm-6"><div class="info-label">Alt Phone</div><div class="info-value"><?php echo e($employee->emergency_alt_phone ?? 'N/A'); ?></div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Identity & Bank Tab -->
        <div class="tab-pane fade" id="docs" role="tabpanel">
            <div class="row">
                <div class="col-md-6">
                    <div class="info-card h-100">
                        <div class="info-card-title"><i class="fa fa-id-card"></i> Identity Documents</div>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <tbody>
                                    <tr>
                                        <td class="text-muted fw-semibold" style="width: 35%;">Aadhaar</td>
                                        <td class="fw-medium"><?php echo e($employee->aadhaar ?? 'N/A'); ?></td>
                                        <td class="text-end"><?php if($employee->aadhaar_file): ?> <a href="<?php echo e(Storage::url($employee->aadhaar_file)); ?>" target="_blank" class="btn btn-sm btn-light text-primary"><i class="fa fa-eye"></i> View</a> <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">PAN</td>
                                        <td class="fw-medium"><?php echo e($employee->pan ?? 'N/A'); ?></td>
                                        <td class="text-end"><?php if($employee->pan_file): ?> <a href="<?php echo e(Storage::url($employee->pan_file)); ?>" target="_blank" class="btn btn-sm btn-light text-primary"><i class="fa fa-eye"></i> View</a> <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Passport</td>
                                        <td class="fw-medium"><?php echo e($employee->passport ?? 'N/A'); ?></td>
                                        <td class="text-end"><?php if($employee->passport_file): ?> <a href="<?php echo e(Storage::url($employee->passport_file)); ?>" target="_blank" class="btn btn-sm btn-light text-primary"><i class="fa fa-eye"></i> View</a> <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Driving License</td>
                                        <td class="fw-medium"><?php echo e($employee->driving_license ?? 'N/A'); ?></td>
                                        <td class="text-end"><?php if($employee->license_file): ?> <a href="<?php echo e(Storage::url($employee->license_file)); ?>" target="_blank" class="btn btn-sm btn-light text-primary"><i class="fa fa-eye"></i> View</a> <?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="info-card h-100">
                        <div class="info-card-title"><i class="fa fa-bank"></i> Bank Details</div>
                        <div class="row">
                            <div class="col-sm-6"><div class="info-label">Bank Name</div><div class="info-value"><?php echo e($employee->bank_name ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Account Holder</div><div class="info-value"><?php echo e($employee->account_holder ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Account Number</div><div class="info-value"><?php echo e($employee->account_number ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">IFSC Code</div><div class="info-value"><?php echo e($employee->ifsc ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Branch</div><div class="info-value"><?php echo e($employee->branch ?? 'N/A'); ?></div></div>
                            <div class="col-sm-6"><div class="info-label">Bank Document</div><div class="info-value"><?php if($employee->bank_document): ?> <a href="<?php echo e(Storage::url($employee->bank_document)); ?>" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fa fa-external-link-alt"></i> View File</a> <?php else: ?> N/A <?php endif; ?></div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Education & Experience Tab -->
        <div class="tab-pane fade" id="edu" role="tabpanel">
            <div class="info-card mb-4">
                <div class="info-card-title"><i class="fa fa-graduation-cap"></i> Education</div>
                <?php if($employee->education->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light text-muted">
                            <tr><th>Qualification</th><th>Course</th><th>Institution</th><th>Year</th><th>% / CGPA</th><th class="text-end">Document</th></tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employee->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="fw-bold text-dark"><?php echo e($edu->qualification); ?></span></td>
                                <td><?php echo e($edu->course); ?></td>
                                <td><?php echo e($edu->institution); ?></td>
                                <td><?php echo e($edu->year); ?></td>
                                <td><span class="badge bg-light text-dark border"><?php echo e($edu->percentage); ?></span></td>
                                <td class="text-end"><?php if($edu->certificate): ?> <a href="<?php echo e(Storage::url($edu->certificate)); ?>" target="_blank" class="btn btn-sm btn-light text-primary py-1"><i class="fa fa-eye"></i> View</a> <?php else: ?> <span class="text-muted">-</span> <?php endif; ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-4 text-muted"><i class="fa fa-folder-open fs-3 mb-2 opacity-50"></i><p class="mb-0">No education details found.</p></div>
                <?php endif; ?>
            </div>

            <div class="info-card mb-4">
                <div class="info-card-title"><i class="fa fa-briefcase"></i> Experience</div>
                <?php if($employee->experience->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light text-muted">
                            <tr><th>Company</th><th>Designation</th><th>Duration</th><th>Years</th><th class="text-end">Document</th></tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employee->experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="fw-bold text-dark"><?php echo e($exp->company); ?></span></td>
                                <td><?php echo e($exp->designation); ?></td>
                                <td><?php echo e($exp->from_date); ?> <i class="fa fa-arrow-right mx-1 text-muted fs-7"></i> <?php echo e($exp->to_date); ?></td>
                                <td><span class="badge bg-light text-dark border"><?php echo e($exp->years); ?> yrs</span></td>
                                <td class="text-end"><?php if($exp->certificate): ?> <a href="<?php echo e(Storage::url($exp->certificate)); ?>" target="_blank" class="btn btn-sm btn-light text-primary py-1"><i class="fa fa-eye"></i> View</a> <?php else: ?> <span class="text-muted">-</span> <?php endif; ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-4 text-muted"><i class="fa fa-folder-open fs-3 mb-2 opacity-50"></i><p class="mb-0">No experience details found.</p></div>
                <?php endif; ?>
            </div>
            
            <div class="info-card">
                <div class="info-card-title"><i class="fa fa-certificate"></i> Certifications</div>
                <?php if($employee->certificates->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light text-muted">
                            <tr><th>Certificate Name</th><th>Issued By</th><th>Issue Date</th><th>Expiry Date</th><th class="text-end">Document</th></tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employee->certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="fw-bold text-dark"><?php echo e($cert->certificate_name); ?></span></td>
                                <td><?php echo e($cert->issued_by); ?></td>
                                <td><?php echo e($cert->issued_date); ?></td>
                                <td><?php echo e($cert->expiry_date); ?></td>
                                <td class="text-end"><?php if($cert->file): ?> <a href="<?php echo e(Storage::url($cert->file)); ?>" target="_blank" class="btn btn-sm btn-light text-primary py-1"><i class="fa fa-eye"></i> View</a> <?php else: ?> <span class="text-muted">-</span> <?php endif; ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-4 text-muted"><i class="fa fa-folder-open fs-3 mb-2 opacity-50"></i><p class="mb-0">No certifications found.</p></div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Assets Tab -->
        <div class="tab-pane fade" id="assets" role="tabpanel">

            
            <?php if($employee->provided_assets && count(array_filter($employee->provided_assets))): ?>
            <div class="info-card mb-4">
                <div class="info-card-title"><i class="fa fa-box-open"></i> Assets Provided at Joining</div>
                <div class="d-flex flex-wrap gap-2">
                    <?php $__currentLoopData = $employee->provided_assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value && $value !== 'null' && $key !== 'sim_number' && $key !== 'other_details'): ?>
                            <span class="badge px-3 py-2 fs-6" style="background:linear-gradient(135deg,#2f3092,#0070bc);color:white;border-radius:8px;">
                                <i class="fa fa-check-circle me-1"></i>
                                <?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>

                            </span>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!empty($employee->provided_assets['sim_number'])): ?>
                        <span class="badge px-3 py-2 fs-6" style="background:linear-gradient(135deg,#0070bc,#00aa9e);color:white;border-radius:8px;">
                            <i class="fa fa-sim-card me-1"></i> SIM: <?php echo e($employee->provided_assets['sim_number']); ?>

                        </span>
                    <?php endif; ?>
                    <?php if(!empty($employee->provided_assets['other_details'])): ?>
                        <span class="badge px-3 py-2 fs-6 bg-secondary">
                            <i class="fa fa-info-circle me-1"></i> <?php echo e($employee->provided_assets['other_details']); ?>

                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            
            <div class="info-card">
                <div class="info-card-title"><i class="fa fa-laptop"></i> Formally Assigned Assets</div>
                <?php if($employee->assetAssignments && $employee->assetAssignments->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light text-muted">
                            <tr>
                                <th>Asset Name</th>
                                <th>Type</th>
                                <th>Serial Number</th>
                                <th>Assigned Date</th>
                                <th>Condition Given</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employee->assetAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="fw-bold text-dark"><?php echo e($assignment->asset->name ?? 'N/A'); ?></span></td>
                                <td>
                                    <span class="badge bg-light text-dark border">
                                        <?php echo e($assignment->asset->type ?? 'N/A'); ?>

                                    </span>
                                </td>
                                <td><code><?php echo e($assignment->asset->serial_number ?? 'N/A'); ?></code></td>
                                <td><?php echo e($assignment->assigned_date ?? 'N/A'); ?></td>
                                <td><?php echo e($assignment->condition_given ?? '—'); ?></td>
                                <td>
                                    <?php if($assignment->returned_date): ?>
                                        <span class="badge bg-secondary">
                                            <i class="fa fa-undo me-1"></i>Returned on <?php echo e($assignment->returned_date); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-success">
                                            <i class="fa fa-check me-1"></i>In Possession
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-4 text-muted">
                    <i class="fa fa-desktop fs-3 mb-2 d-block opacity-50"></i>
                    <p class="mb-0">No formal asset assignments found.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\SMEClLABS\Documents\projects\2026\july\smec-eims\resources\views/admin/employees/show_modal.blade.php ENDPATH**/ ?>