﻿

<?php $__env->startSection('content'); ?>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
    body { background-color: #f8f9fc; }
    .att-font { font-family: 'Inter', sans-serif; }
    
    /* Summary Cards */
    .att-summary-card {
        background: #ffffff;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        padding: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    }
    .att-summary-title { font-size: 0.8rem; color: #64748b; font-weight: 600; margin-bottom: 4px; }
    .att-summary-value { font-size: 1.5rem; font-weight: 700; color: #1e293b; }
    .att-summary-icon {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
    }
    .icon-total { background: #f1f5f9; color: #64748b; }
    .icon-present { background: #dcfce7; color: #16a34a; }
    .icon-absent { background: #fee2e2; color: #dc2626; }
    .icon-late { background: #ffedd5; color: #ea580c; }
    .icon-half { background: #fef3c7; color: #d97706; }
    .icon-leave { background: #e0e7ff; color: #4f46e5; }
    
    .text-present { color: #16a34a !important; }
    .text-absent { color: #dc2626 !important; }
    .text-late { color: #ea580c !important; }
    .text-half { color: #d97706 !important; }
    .text-leave { color: #4f46e5 !important; }

    /* Filters Section */
    .att-filter-card {
        background: #ffffff;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        padding: 24px;
        margin-top: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    }
    .att-filter-label { font-size: 0.75rem; font-weight: 700; color: #64748b; margin-bottom: 8px; display: block; }
    .att-filter-select, .att-filter-input {
        border-radius: 8px; border: 1px solid #cbd5e1; padding: 10px 14px; font-size: 0.85rem; width: 100%;
        color: #334155; font-weight: 500; outline: none; transition: border-color 0.2s;
    }
    .att-filter-select:focus, .att-filter-input:focus { border-color: #4f46e5; }

    /* Table Section */
    .att-table-card {
        background: #ffffff;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        margin-top: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        overflow: hidden;
    }
    .att-table-header { padding: 20px 24px; border-bottom: 1px solid #e2e8f0; font-weight: 700; color: #1e293b; font-size: 1.1rem; }
    .att-table { width: 100%; border-collapse: collapse; }
    .att-table th { background: #f8fafc; padding: 12px 24px; text-align: left; font-size: 0.7rem; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e2e8f0; }
    .att-table td { padding: 16px 24px; border-bottom: 1px solid #f1f5f9; font-size: 0.85rem; color: #334155; vertical-align: middle; }
    .att-table tr:last-child td { border-bottom: none; }
    
    .status-pill { padding: 4px 12px; border-radius: 20px; font-size: 0.7rem; font-weight: 700; }
    .pill-present { background: #dcfce7; color: #15803d; }
    .pill-absent { background: #fee2e2; color: #b91c1c; }
    .pill-late { background: #ffedd5; color: #c2410c; }
    .pill-half { background: #fef3c7; color: #b45309; }
    .pill-leave { background: #e0e7ff; color: #4338ca; }

    .btn-primary-custom { background: #4f46e5; color: white; border-radius: 8px; padding: 10px 20px; font-weight: 600; border: none; font-size: 0.85rem; transition: background 0.2s; }
    .btn-primary-custom:hover { background: #4338ca; color: white; }
    .btn-outline-custom { background: white; color: #4f46e5; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px 20px; font-weight: 600; font-size: 0.85rem; transition: all 0.2s; }
    .btn-outline-custom:hover { background: #f8fafc; border-color: #4f46e5; color: #4f46e5;}
</style>

<div class="att-font pb-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold text-dark mb-1" style="font-size: 1.5rem;">Attendance Logs</h2>
            <p class="text-muted small mb-0">Track and manage employee attendance records</p>
        </div>
        <div>
            <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#addAttModal">
                <i class="fa-solid fa-plus me-2"></i> Add Log
            </button>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success border-0 shadow-sm" style="border-radius: 12px; font-size: 0.9rem; font-weight: 500;">
            <i class="fa-solid fa-check-circle me-2"></i><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 text-sm font-medium">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div><i class="fa-solid fa-xmark-circle me-2"></i><?php echo e($e); ?></div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <!-- Summary Cards -->
    <div class="row g-3">
        <div class="col-md-2 col-sm-4">
            <div class="att-summary-card">
                <div>
                    <div class="att-summary-title">Total Logs</div>
                    <div class="att-summary-value"><?php echo e($stats['total']); ?></div>
                </div>
                <div class="att-summary-icon icon-total"><i class="fa-regular fa-calendar-days"></i></div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4">
            <div class="att-summary-card">
                <div>
                    <div class="att-summary-title">Present</div>
                    <div class="att-summary-value text-present"><?php echo e($stats['present']); ?></div>
                </div>
                <div class="att-summary-icon icon-present"><i class="fa-solid fa-check"></i></div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4">
            <div class="att-summary-card">
                <div>
                    <div class="att-summary-title">Absent</div>
                    <div class="att-summary-value text-absent"><?php echo e($stats['absent']); ?></div>
                </div>
                <div class="att-summary-icon icon-absent"><i class="fa-solid fa-xmark"></i></div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4">
            <div class="att-summary-card">
                <div>
                    <div class="att-summary-title">Late</div>
                    <div class="att-summary-value text-late"><?php echo e($stats['late']); ?></div>
                </div>
                <div class="att-summary-icon icon-late"><i class="fa-regular fa-clock"></i></div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4">
            <div class="att-summary-card">
                <div>
                    <div class="att-summary-title">Half-Day</div>
                    <div class="att-summary-value text-half"><?php echo e($stats['half_day']); ?></div>
                </div>
                <div class="att-summary-icon icon-half"><i class="fa-solid fa-circle-half-stroke"></i></div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4">
            <div class="att-summary-card">
                <div>
                    <div class="att-summary-title">On Leave</div>
                    <div class="att-summary-value text-leave"><?php echo e($stats['leave']); ?></div>
                </div>
                <div class="att-summary-icon icon-leave"><i class="fa-solid fa-bed"></i></div>
            </div>
        </div>
    </div>

    <!-- Filters Section -->
    <div class="att-filter-card">
        <form method="GET" action="<?php echo e(route('admin.attendance.index')); ?>" id="filterForm">
            <div class="row g-3 align-items-end">
                <div class="col-md-2">
                    <label class="att-filter-label">Date Filter</label>
                    <select name="date_filter_type" id="dateFilterType" class="att-filter-select">
                        <option value="date" <?php echo e(request('date_filter_type', 'date') == 'date' ? 'selected' : ''); ?>>Single Date</option>
                        <option value="month" <?php echo e(request('date_filter_type') == 'month' ? 'selected' : ''); ?>>Monthly</option>
                        <option value="year" <?php echo e(request('date_filter_type') == 'year' ? 'selected' : ''); ?>>Yearly</option>
                        <option value="custom" <?php echo e(request('date_filter_type') == 'custom' ? 'selected' : ''); ?>>Custom Range</option>
                    </select>
                </div>

                <div class="col-md-2" id="singleDateDiv">
                    <label class="att-filter-label">Select Date</label>
                    <input type="date" name="date" class="att-filter-input" value="<?php echo e(request('date', date('Y-m-d'))); ?>">
                </div>

                <div class="col-md-2" id="yearDiv" style="display: none;">
                    <label class="att-filter-label">Year</label>
                    <select name="year" class="att-filter-select">
                        <?php for($y = date('Y'); $y >= date('Y')-3; $y--): ?>
                            <option value="<?php echo e($y); ?>" <?php echo e(request('year', date('Y')) == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="col-md-2" id="monthDiv" style="display: none;">
                    <label class="att-filter-label">Month</label>
                    <select name="month" class="att-filter-select">
                        <?php for($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo e(sprintf('%02d', $m)); ?>" <?php echo e(request('month', date('m')) == sprintf('%02d', $m) ? 'selected' : ''); ?>>
                                <?php echo e(date('F', mktime(0,0,0,$m,1))); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="col-md-2" id="startDiv" style="display: none;">
                    <label class="att-filter-label">Start Date</label>
                    <input type="date" name="start_date" class="att-filter-input" value="<?php echo e(request('start_date')); ?>">
                </div>
                <div class="col-md-2" id="endDiv" style="display: none;">
                    <label class="att-filter-label">End Date</label>
                    <input type="date" name="end_date" class="att-filter-input" value="<?php echo e(request('end_date')); ?>">
                </div>

                <div class="col-md-2">
                    <label class="att-filter-label">Department</label>
                    <select name="department_id" class="att-filter-select">
                        <option value="">All Departments</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dept->id); ?>" <?php echo e(request('department_id') == $dept->id ? 'selected' : ''); ?>><?php echo e($dept->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="col-md-2">
                    <label class="att-filter-label">Employee</label>
                    <select name="employee_id" class="att-filter-select">
                        <option value="">All Employees</option>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($emp->id); ?>" <?php echo e(request('employee_id') == $emp->id ? 'selected' : ''); ?>><?php echo e($emp->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="att-filter-label">Status</label>
                    <select name="status" class="att-filter-select">
                        <option value="">All Status</option>
                        <option value="Present" <?php echo e(request('status') == 'Present' ? 'selected' : ''); ?>>Present</option>
                        <option value="Absent" <?php echo e(request('status') == 'Absent' ? 'selected' : ''); ?>>Absent</option>
                        <option value="Late" <?php echo e(request('status') == 'Late' ? 'selected' : ''); ?>>Late</option>
                        <option value="Half-Day" <?php echo e(request('status') == 'Half-Day' ? 'selected' : ''); ?>>Half-Day</option>
                        <option value="Leave" <?php echo e(request('status') == 'Leave' ? 'selected' : ''); ?>>Leave</option>
                    </select>
                </div>

                <div class="col-md-12 d-flex justify-content-end gap-2 mt-4 pt-2 border-top">
                    <?php if(request()->anyFilled(['department_id', 'employee_id', 'status']) || request('date_filter_type', 'date') != 'date'): ?>
                        <a href="<?php echo e(route('admin.attendance.index')); ?>" class="btn-outline-custom text-decoration-none text-center">Clear</a>
                    <?php endif; ?>
                    <button type="button" class="btn-outline-custom" onclick="exportExcel()"><i class="fa-solid fa-file-excel me-2"></i>Export to Excel</button>
                    <button type="submit" class="btn-primary-custom">Apply Filters</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Table Section -->
    <div class="att-table-card">
        <div class="att-table-header">Attendance Records</div>
        <?php if($attendances->isEmpty()): ?>
            <div class="text-center py-5">
                <i class="fa-regular fa-calendar-xmark text-muted mb-3" style="font-size: 2.5rem;"></i>
                <h6 class="fw-bold text-dark">No records found</h6>
                <p class="text-muted small">Try adjusting your filters.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="att-table">
                    <thead>
                        <tr>
                            <th>Employee</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Check In</th>
                            <th>Check Out</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="fw-bold text-dark" style="font-size: 0.9rem;"><?php echo e($att->employee->name ?? 'Unknown'); ?></div>
                                    <div class="text-muted" style="font-size: 0.75rem;"><?php echo e($att->employee->employee_id ?? ''); ?> • <?php echo e($att->employee->departmentRel->name ?? 'General'); ?></div>
                                </td>
                                <td>
                                    <div class="fw-medium text-dark"><?php echo e(\Carbon\Carbon::parse($att->date)->format('M d, Y')); ?></div>
                                </td>
                                <td>
                                    <?php
                                        $pillClass = match($att->status) {
                                            'Present' => 'pill-present',
                                            'Absent' => 'pill-absent',
                                            'Late' => 'pill-late',
                                            'Half-Day' => 'pill-half',
                                            'Leave' => 'pill-leave',
                                            default => 'pill-present'
                                        };
                                    ?>
                                    <span class="status-pill <?php echo e($pillClass); ?>"><?php echo e($att->status); ?></span>
                                </td>
                                <td class="fw-medium text-dark"><?php echo e($att->check_in ? \Carbon\Carbon::parse($att->check_in)->format('h:i A') : '—'); ?></td>
                                <td class="fw-medium text-dark"><?php echo e($att->check_out ? \Carbon\Carbon::parse($att->check_out)->format('h:i A') : '—'); ?></td>
                                <td class="text-end">
                                    <form action="<?php echo e(route('admin.attendance.destroy', $att->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this record?');">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="bg-light text-secondary border rounded" style="padding: 4px 10px; transition: 0.2s;"><i class="fa-solid fa-trash-can"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addAttModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 16px;">
            <div class="modal-header border-bottom-0 pb-0">
                <h5 class="modal-title fw-bold" id="modalTitle"><i class="fa-solid fa-plus-circle text-primary me-2"></i>Add Attendance Log</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-3 pb-4">
                <form action="<?php echo e(route('admin.attendance.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold text-secondary text-uppercase" style="font-size: 0.75rem;">Employee</label>
                        <select name="employee_id" required class="form-control">
                            <option value="">Select Employee...</option>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($e->id); ?>"><?php echo e($e->employee_id); ?> - <?php echo e($e->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold text-secondary text-uppercase" style="font-size: 0.75rem;">Date</label>
                            <input type="date" name="date" value="<?php echo e(date('Y-m-d')); ?>" required class="form-control">
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold text-secondary text-uppercase" style="font-size: 0.75rem;">Status</label>
                            <select name="status" required class="form-control">
                                <option value="Present">Present</option>
                                <option value="Absent">Absent</option>
                                <option value="Half-Day">Half-Day</option>
                                <option value="Late">Late</option>
                                <option value="Leave">Leave</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-6">
                            <label class="form-label fw-bold text-secondary text-uppercase" style="font-size: 0.75rem;">Check In</label>
                            <input type="time" name="check_in" class="form-control">
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold text-secondary text-uppercase" style="font-size: 0.75rem;">Check Out</label>
                            <input type="time" name="check_out" class="form-control">
                        </div>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary fw-bold py-2">Save Log</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    function toggleDateInputs() {
        const type = document.getElementById('dateFilterType').value;
        document.getElementById('singleDateDiv').style.display = (type === 'date') ? 'block' : 'none';
        document.getElementById('yearDiv').style.display = (type === 'year' || type === 'month') ? 'block' : 'none';
        document.getElementById('monthDiv').style.display = (type === 'month') ? 'block' : 'none';
        document.getElementById('startDiv').style.display = (type === 'custom') ? 'block' : 'none';
        document.getElementById('endDiv').style.display = (type === 'custom') ? 'block' : 'none';
    }

    document.getElementById('dateFilterType').addEventListener('change', toggleDateInputs);
    toggleDateInputs();

    function exportExcel() {
        const form = document.getElementById('filterForm');
        const originalAction = form.action;
        form.action = "<?php echo e(route('admin.attendance.export')); ?>";
        form.submit();
        form.action = originalAction;
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\SMEClLABS\Documents\projects\2026\july\smec-eims\resources\views/admin/attendance/index.blade.php ENDPATH**/ ?>