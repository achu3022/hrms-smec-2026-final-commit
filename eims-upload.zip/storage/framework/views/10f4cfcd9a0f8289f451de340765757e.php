<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <title>Employee Dashboard - <?php echo e(config('app.name', 'HRMS')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f0f4f8; }
        
        /* Desktop Sidebar */
        .desktop-sidebar {
            width: 250px;
            background-color: #2b3a67; /* Dark blue from screenshot */
            color: #e2e8f0;
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            z-index: 40;
            overflow-y: auto;
        }
        
        .sidebar-item {
            display: flex;
            align-items: center;
            padding: 12px 24px;
            color: #cbd5e1;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.2s;
            margin: 4px 12px;
            border-radius: 8px;
        }
        
        .sidebar-item:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .sidebar-item.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: white;
            font-weight: 500;
        }
        
        .sidebar-item i {
            width: 24px;
            font-size: 1.1rem;
        }

        /* Topbar */
        .desktop-topbar {
            margin-left: 250px;
            height: 70px;
            background-color: white;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 32px;
            position: sticky;
            top: 0;
            z-index: 30;
        }

        /* Main Layout Content */
        .desktop-content {
            margin-left: 250px;
            padding: 32px;
            min-height: calc(100vh - 70px);
        }

        /* Mobile Adjustments */
        @media (max-width: 1024px) {
            .desktop-sidebar { display: none; }
            .desktop-topbar { margin-left: 0; padding: 0 16px; }
            .desktop-content { margin-left: 0; padding: 16px; padding-bottom: 80px; }
            body { background-color: #f0f3f6; }
        }

        /* Mobile Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            z-index: 50;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.05);
        }
        .bottom-nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #64748b;
            text-decoration: none;
            font-size: 0.75rem;
            font-weight: 500;
            transition: color 0.2s;
            width: 25%;
        }
        .bottom-nav-item i {
            font-size: 1.25rem;
            margin-bottom: 4px;
        }
        .bottom-nav-item.active {
            color: #4f46e5;
        }
        
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="antialiased text-gray-900">

    <!-- Desktop Sidebar -->
    <aside class="desktop-sidebar hidden lg:block shadow-xl">
        <div class="px-6 py-6 mb-4 flex items-center gap-3">
            <div class="bg-white rounded p-1">
                <img src="<?php echo e(asset('logo-new.webp')); ?>" class="h-6" alt="Logo">
            </div>
            <div>
                <div class="font-bold text-white text-lg leading-none">HRMS</div>
                <div class="text-xs text-indigo-200">Employee</div>
            </div>
        </div>

        <nav class="flex flex-col gap-1">
            <a href="<?php echo e(route('employee.dashboard')); ?>"
               class="sidebar-item <?php echo e(request()->routeIs('employee.dashboard') ? 'active' : ''); ?>">
                <i class="fa-solid fa-house"></i> Dashboard
            </a>
            <a href="<?php echo e(route('employee.attendance.index')); ?>"
               class="sidebar-item <?php echo e(request()->routeIs('employee.attendance.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-clock"></i> Attendance
            </a>
            <a href="<?php echo e(route('employee.leaves.index')); ?>"
               class="sidebar-item <?php echo e(request()->routeIs('employee.leaves.*') ? 'active' : ''); ?>">
                <i class="fa-regular fa-calendar-minus"></i> Leaves
            </a>
            <a href="<?php echo e(route('employee.profile.index')); ?>"
               class="sidebar-item <?php echo e(request()->routeIs('employee.profile.*') ? 'active' : ''); ?>">
                <i class="fa-regular fa-user"></i> Profile
            </a>
        </nav>
    </aside>

    <!-- Topbar -->
    <header class="desktop-topbar">
        <div class="lg:hidden flex items-center gap-2">
            <img src="<?php echo e(asset('logo-new.webp')); ?>" class="h-8" alt="Logo">
            <span class="font-bold text-gray-800 text-lg">Portal</span>
        </div>
        <div class="hidden lg:block">
            <h1 class="text-xl font-bold text-slate-800">Employee Dashboard</h1>
            <p class="text-xs text-slate-500">Welcome back!</p>
        </div>

        <div class="flex items-center gap-6">
            <div class="hidden sm:flex items-center gap-4 text-slate-400">
                <button class="hover:text-slate-600 transition-colors"><i class="fa-regular fa-bell"></i></button>
                <button class="hover:text-slate-600 transition-colors"><i class="fa-regular fa-envelope"></i></button>
            </div>
            
            <div class="flex items-center gap-3">
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700"><?php echo e(Auth::guard('employee')->user()->employee->name ?? 'Employee'); ?></div>
                    <div class="text-xs text-slate-400"><?php echo e(Auth::guard('employee')->user()->employee->designation ?? 'Staff'); ?></div>
                </div>
                <div class="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold overflow-hidden shadow-sm">
                    <?php if(Auth::guard('employee')->user()->employee && Auth::guard('employee')->user()->employee->photo): ?>
                        <img src="<?php echo e(asset('storage/' . Auth::guard('employee')->user()->employee->photo)); ?>" class="h-full w-full object-cover">
                    <?php else: ?>
                        <?php echo e(substr(Auth::guard('employee')->user()->employee->name ?? 'E', 0, 1)); ?>

                    <?php endif; ?>
                </div>
                
                <form method="POST" action="<?php echo e(route('employee.logout')); ?>" class="ml-2">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="text-slate-400 hover:text-red-500 transition-colors text-xl" title="Logout">
                        <i class="fa-solid fa-arrow-right-from-bracket"></i>
                    </button>
                </form>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="desktop-content">
        <?php echo $__env->yieldContent('content'); ?>
    </main>



    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\SMEClLABS\Documents\projects\2026\july\smec-eims\resources\views/employee/portal/layout.blade.php ENDPATH**/ ?>