﻿

<?php $__env->startPush('styles'); ?>
<style>
    .pf-card { background:#fff; border:1px solid #e2e8f0; border-radius:14px; padding:20px; margin-bottom:20px; }
    .pf-section-title { font-size:.7rem; font-weight:800; color:#6366f1; text-transform:uppercase; letter-spacing:.6px; margin-bottom:14px; padding-bottom:8px; border-bottom:1px solid #f1f5f9; display:flex; align-items:center; gap:6px; }
    .pf-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
    @media(max-width:640px){ .pf-grid{ grid-template-columns:1fr; } }
    .pf-field { display:flex; flex-direction:column; gap:3px; }
    .pf-label { font-size:.68rem; font-weight:700; color:#94a3b8; text-transform:uppercase; letter-spacing:.4px; }
    .pf-value { font-size:.88rem; font-weight:600; color:#1e293b; }
    .pf-value.empty { color:#cbd5e1; font-style:italic; font-weight:400; }
    .pf-avatar-ring {
        width:80px; height:80px; border-radius:50%;
        background:linear-gradient(135deg,#6366f1,#2b3a67);
        display:flex; align-items:center; justify-content:center;
        font-size:2rem; font-weight:800; color:#fff; overflow:hidden;
        box-shadow:0 4px 14px rgba(99,102,241,.3);
    }
    .pf-status-pill { display:inline-flex; align-items:center; gap:4px; font-size:.72rem; font-weight:700; padding:3px 10px; border-radius:6px; }
    .status-active   { background:#dcfce7; color:#16a34a; }
    .status-inactive { background:#fee2e2; color:#dc2626; }
    .pf-doc-link { display:inline-flex; align-items:center; gap:6px; font-size:0.75rem; font-weight:600; color:#4f46e5; background:#e0e7ff; padding:4px 10px; border-radius:6px; text-decoration:none; transition:background 0.2s; }
    .pf-doc-link:hover { background:#c7d2fe; color:#4338ca; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-5">
    <h2 class="text-xl font-bold text-slate-800">My Profile</h2>
    <p class="text-sm text-slate-400 mt-0.5">Your personal and employment information</p>
</div>


<div class="pf-card">
    <div class="flex flex-col sm:flex-row items-center sm:items-start gap-5">
        <div class="pf-avatar-ring">
            <?php if($employee->photo): ?>
                <img src="<?php echo e(asset('storage/'.$employee->photo)); ?>" class="h-full w-full object-cover">
            <?php else: ?>
                <?php echo e(strtoupper(substr($employee->name,0,1))); ?>

            <?php endif; ?>
        </div>
        <div class="flex-1 text-center sm:text-left">
            <h3 class="text-xl font-bold text-slate-800"><?php echo e($employee->name); ?></h3>
            <p class="text-sm text-slate-500 mt-0.5"><?php echo e($employee->designationRel->name ?? $employee->designation ?? 'Staff'); ?> &bull; <?php echo e($employee->departmentRel->name ?? $employee->department ?? 'General'); ?></p>
            <div class="flex flex-wrap gap-2 mt-3 justify-center sm:justify-start">
                <span class="pf-status-pill <?php echo e($employee->status==='Active' ? 'status-active' : 'status-inactive'); ?>">
                    <i class="fa-solid fa-circle" style="font-size:.5rem;"></i> <?php echo e($employee->status); ?>

                </span>
                <span class="pf-status-pill" style="background:#ede9fe;color:#7c3aed;"><i class="fa-solid fa-id-badge"></i> <?php echo e($employee->employee_id); ?></span>
                <?php if($employee->employment_type): ?>
                <span class="pf-status-pill" style="background:#fff0f6;color:#d6336c;"><i class="fa-solid fa-briefcase"></i> <?php echo e($employee->employment_type); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<div class="pf-card">
    <div class="pf-section-title"><i class="fa-solid fa-user"></i> Personal Information</div>
    <div class="pf-grid">
        <div class="pf-field"><span class="pf-label">Full Name</span><span class="pf-value"><?php echo e($employee->name); ?></span></div>
        <div class="pf-field"><span class="pf-label">Date of Birth</span><span class="pf-value <?php echo e(!$employee->dob ? 'empty' : ''); ?>"><?php echo e($employee->dob ? \Carbon\Carbon::parse($employee->dob)->format('d M Y') : 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Gender</span><span class="pf-value <?php echo e(!$employee->gender ? 'empty' : ''); ?>"><?php echo e($employee->gender ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Blood Group</span><span class="pf-value <?php echo e(!$employee->blood_group ? 'empty' : ''); ?>"><?php echo e($employee->blood_group ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Marital Status</span><span class="pf-value <?php echo e(!$employee->marital_status ? 'empty' : ''); ?>"><?php echo e($employee->marital_status ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Personal Email</span><span class="pf-value <?php echo e(!$employee->personal_email ? 'empty' : ''); ?>"><?php echo e($employee->personal_email ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Personal Phone</span><span class="pf-value <?php echo e(!$employee->personal_phone ? 'empty' : ''); ?>"><?php echo e($employee->personal_phone ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Office Phone</span><span class="pf-value <?php echo e(!$employee->office_phone ? 'empty' : ''); ?>"><?php echo e($employee->office_phone ?? 'Not provided'); ?></span></div>
    </div>
    <?php if($employee->present_address || $employee->permanent_address): ?>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-14 mt-4">
        <div class="pf-field"><span class="pf-label">Present Address</span><span class="pf-value" style="white-space:pre-line;"><?php echo e($employee->present_address ?? '—'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Permanent Address</span><span class="pf-value" style="white-space:pre-line;"><?php echo e($employee->permanent_address ?? '—'); ?></span></div>
    </div>
    <?php endif; ?>
</div>


<div class="pf-card">
    <div class="pf-section-title"><i class="fa-solid fa-id-card"></i> Identity Documents & Numbers</div>
    <div class="pf-grid mb-4">
        <div class="pf-field"><span class="pf-label">Aadhaar Number</span><span class="pf-value <?php echo e(!$employee->aadhaar ? 'empty' : ''); ?>"><?php echo e($employee->aadhaar ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">PAN Number</span><span class="pf-value <?php echo e(!$employee->pan ? 'empty' : ''); ?>"><?php echo e($employee->pan ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Passport Number</span><span class="pf-value <?php echo e(!$employee->passport ? 'empty' : ''); ?>"><?php echo e($employee->passport ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Driving License</span><span class="pf-value <?php echo e(!$employee->driving_license ? 'empty' : ''); ?>"><?php echo e($employee->driving_license ?? 'Not provided'); ?></span></div>
    </div>
    <div class="flex flex-wrap gap-3 mt-2 border-t border-slate-100 pt-4">
        <?php if($employee->aadhaar_file): ?>
            <a href="<?php echo e(asset('storage/'.$employee->aadhaar_file)); ?>" target="_blank" class="pf-doc-link"><i class="fa-solid fa-file-pdf"></i> View Aadhaar Card</a>
        <?php endif; ?>
        <?php if($employee->pan_file): ?>
            <a href="<?php echo e(asset('storage/'.$employee->pan_file)); ?>" target="_blank" class="pf-doc-link"><i class="fa-solid fa-file-pdf"></i> View PAN Card</a>
        <?php endif; ?>
        <?php if($employee->passport_file): ?>
            <a href="<?php echo e(asset('storage/'.$employee->passport_file)); ?>" target="_blank" class="pf-doc-link"><i class="fa-solid fa-file-pdf"></i> View Passport</a>
        <?php endif; ?>
        <?php if($employee->license_file): ?>
            <a href="<?php echo e(asset('storage/'.$employee->license_file)); ?>" target="_blank" class="pf-doc-link"><i class="fa-solid fa-file-pdf"></i> View Driving License</a>
        <?php endif; ?>
        <?php if(!$employee->aadhaar_file && !$employee->pan_file && !$employee->passport_file && !$employee->license_file): ?>
            <span class="text-xs text-slate-400 italic">No document files uploaded yet.</span>
        <?php endif; ?>
    </div>
</div>


<div class="pf-card">
    <div class="pf-section-title"><i class="fa-solid fa-briefcase"></i> Employment Details</div>
    <div class="pf-grid">
        <div class="pf-field"><span class="pf-label">Employee ID</span><span class="pf-value"><?php echo e($employee->employee_id); ?></span></div>
        <div class="pf-field"><span class="pf-label">Company Email</span><span class="pf-value <?php echo e(!$employee->company_email ? 'empty' : ''); ?>"><?php echo e($employee->company_email ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Department</span><span class="pf-value <?php echo e(!($employee->departmentRel->name ?? $employee->department) ? 'empty' : ''); ?>"><?php echo e($employee->departmentRel->name ?? $employee->department ?? 'Not assigned'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Designation</span><span class="pf-value <?php echo e(!($employee->designationRel->name ?? $employee->designation) ? 'empty' : ''); ?>"><?php echo e($employee->designationRel->name ?? $employee->designation ?? 'Not assigned'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Joining Date</span><span class="pf-value <?php echo e(!$employee->joining_date ? 'empty' : ''); ?>"><?php echo e($employee->joining_date ? \Carbon\Carbon::parse($employee->joining_date)->format('d M Y') : 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Employment Type</span><span class="pf-value <?php echo e(!$employee->employment_type ? 'empty' : ''); ?>"><?php echo e($employee->employment_type ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Work Location</span><span class="pf-value <?php echo e(!$employee->work_location ? 'empty' : ''); ?>"><?php echo e($employee->work_location ?? 'Not provided'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Reporting Manager</span><span class="pf-value <?php echo e(!$employee->reporting_manager ? 'empty' : ''); ?>"><?php echo e($employee->reporting_manager ?? 'Not provided'); ?></span></div>
    </div>
</div>


<?php if($employee->emergency_name || $employee->emergency_phone): ?>
<div class="pf-card">
    <div class="pf-section-title"><i class="fa-solid fa-phone-volume"></i> Emergency Contact</div>
    <div class="pf-grid">
        <div class="pf-field"><span class="pf-label">Name</span><span class="pf-value"><?php echo e($employee->emergency_name ?? '—'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Relation</span><span class="pf-value"><?php echo e($employee->emergency_relation ?? '—'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Phone</span><span class="pf-value"><?php echo e($employee->emergency_phone ?? '—'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Alternate Phone</span><span class="pf-value"><?php echo e($employee->emergency_alt_phone ?? '—'); ?></span></div>
    </div>
</div>
<?php endif; ?>


<?php if($employee->bank_name || $employee->account_number || $employee->bank_document): ?>
<div class="pf-card">
    <div class="pf-section-title"><i class="fa-solid fa-building-columns"></i> Bank Details</div>
    <div class="pf-grid mb-4">
        <div class="pf-field"><span class="pf-label">Bank Name</span><span class="pf-value"><?php echo e($employee->bank_name ?? '—'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Account Holder</span><span class="pf-value"><?php echo e($employee->account_holder ?? '—'); ?></span></div>
        <div class="pf-field"><span class="pf-label">Account Number</span><span class="pf-value"><?php echo e($employee->account_number ? str_repeat('•',strlen($employee->account_number)-4).substr($employee->account_number,-4) : '—'); ?></span></div>
        <div class="pf-field"><span class="pf-label">IFSC Code</span><span class="pf-value"><?php echo e($employee->ifsc ?? '—'); ?></span></div>
    </div>
    <?php if($employee->bank_document): ?>
    <div class="border-t border-slate-100 pt-4">
        <a href="<?php echo e(asset('storage/'.$employee->bank_document)); ?>" target="_blank" class="pf-doc-link"><i class="fa-solid fa-file-pdf"></i> View Bank Document</a>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>


<?php if($employee->education && $employee->education->isNotEmpty()): ?>
<div class="pf-card">
    <div class="pf-section-title"><i class="fa-solid fa-graduation-cap"></i> Education Details</div>
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse mt-2">
            <thead>
                <tr>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100 rounded-tl-lg">Qualification</th>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100">Course</th>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100">Institution</th>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100">University / Board</th>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100">Year</th>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100">Percentage</th>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100 rounded-tr-lg text-center">Certificate</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $employee->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-colors">
                    <td class="py-3 px-3 text-sm font-semibold text-slate-800"><?php echo e($edu->qualification ?? '—'); ?></td>
                    <td class="py-3 px-3 text-sm text-slate-600"><?php echo e($edu->course ?? '—'); ?></td>
                    <td class="py-3 px-3 text-sm text-slate-600"><?php echo e($edu->institution ?? '—'); ?></td>
                    <td class="py-3 px-3 text-sm text-slate-600"><?php echo e($edu->university ?? '—'); ?></td>
                    <td class="py-3 px-3 text-sm font-medium text-slate-700"><?php echo e($edu->year ?? '—'); ?></td>
                    <td class="py-3 px-3 text-sm font-medium text-indigo-600"><?php echo e($edu->percentage ? $edu->percentage . '%' : '—'); ?></td>
                    <td class="py-3 px-3 text-sm text-center">
                        <?php if($edu->certificate): ?>
                            <a href="<?php echo e(asset('storage/'.$edu->certificate)); ?>" target="_blank" class="text-indigo-600 hover:text-indigo-800" title="View Certificate"><i class="fa-solid fa-file-certificate text-lg"></i> View</a>
                        <?php else: ?>
                            <span class="text-slate-300 text-xs">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>


<?php if($employee->experience && $employee->experience->isNotEmpty()): ?>
<div class="pf-card">
    <div class="pf-section-title"><i class="fa-solid fa-briefcase"></i> Experience Details</div>
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse mt-2">
            <thead>
                <tr>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100 rounded-tl-lg">Company</th>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100">Designation</th>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100">Duration</th>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100">Total Years</th>
                    <th class="py-2 px-3 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-100 rounded-tr-lg text-center">Certificate</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $employee->experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-colors">
                    <td class="py-3 px-3 text-sm font-semibold text-slate-800"><?php echo e($exp->company ?? '—'); ?></td>
                    <td class="py-3 px-3 text-sm text-slate-600"><?php echo e($exp->designation ?? '—'); ?></td>
                    <td class="py-3 px-3 text-sm text-slate-600">
                        <?php echo e($exp->from_date ? \Carbon\Carbon::parse($exp->from_date)->format('M Y') : '—'); ?> 
                        to 
                        <?php echo e($exp->to_date ? \Carbon\Carbon::parse($exp->to_date)->format('M Y') : '—'); ?>

                    </td>
                    <td class="py-3 px-3 text-sm font-medium text-indigo-600"><?php echo e($exp->years ? $exp->years . ' Years' : '—'); ?></td>
                    <td class="py-3 px-3 text-sm text-center">
                        <?php if($exp->certificate): ?>
                            <a href="<?php echo e(asset('storage/'.$exp->certificate)); ?>" target="_blank" class="text-indigo-600 hover:text-indigo-800" title="View Certificate"><i class="fa-solid fa-file-contract text-lg"></i> View</a>
                        <?php else: ?>
                            <span class="text-slate-300 text-xs">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.portal.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\SMEClLABS\Documents\projects\2026\july\smec-eims\resources\views/employee/portal/profile.blade.php ENDPATH**/ ?>