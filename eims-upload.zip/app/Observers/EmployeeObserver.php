<?php

namespace App\Observers;

use App\Models\Employee;

class EmployeeObserver
{
    /**
     * Handle the Employee "created" event.
     */
    public function created(Employee $employee): void
    {
        // Auto-generate employee login account
        if ($employee->employee_id && $employee->dob) {
            $password = \Carbon\Carbon::parse($employee->dob)->format('dmY');
            \App\Models\EmployeeLogin::create([
                'employee_id' => $employee->id,
                'username' => $employee->employee_id,
                'password' => \Illuminate\Support\Facades\Hash::make($password),
                'is_first_login' => true,
            ]);
        }
    }

    /**
     * Handle the Employee "updated" event.
     */
    public function updated(Employee $employee): void
    {
        //
    }

    /**
     * Handle the Employee "deleted" event.
     */
    public function deleted(Employee $employee): void
    {
        //
    }

    /**
     * Handle the Employee "restored" event.
     */
    public function restored(Employee $employee): void
    {
        //
    }

    /**
     * Handle the Employee "force deleted" event.
     */
    public function forceDeleted(Employee $employee): void
    {
        //
    }
}
