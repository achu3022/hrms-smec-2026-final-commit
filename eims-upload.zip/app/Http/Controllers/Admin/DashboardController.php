<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Employee;

class DashboardController extends Controller
{
    public function index()
    {
        $totalEmployees = Employee::count();
        $activeEmployees = Employee::where('status', 'Active')->count();
        $inactiveEmployees = Employee::where('status', 'Inactive')->count();
        $terminatedEmployees = Employee::where('status', 'Terminated')->count();
        $resignedEmployees = Employee::where('status', 'Resigned')->count();
        $departments = \App\Models\Department::count();
        $recentEntries = Employee::with('departmentRel', 'designationRel')->latest()->take(5)->get();

        // Set up the 3-day rolling window range (today, tomorrow, and the day after)
        $startDate = now()->startOfDay();
        $endDate = now()->addDays(2)->endOfDay();

        // Filter employee birthdays falling in [Today, Today + 2 Days]
        $upcomingBirthdays = Employee::with('departmentRel', 'designationRel')->get()->filter(function ($emp) use ($startDate, $endDate) {
            if (!$emp->dob) return false;
            $bdayThisYear = \Carbon\Carbon::parse($emp->dob)->year(now()->year)->startOfDay();
            $bdayNextYear = \Carbon\Carbon::parse($emp->dob)->year(now()->year + 1)->startOfDay();
            return $bdayThisYear->between($startDate, $endDate) || $bdayNextYear->between($startDate, $endDate);
        })->sortBy(function ($emp) {
            return \Carbon\Carbon::parse($emp->dob)->day;
        })->values();

        // Filter employee work anniversaries falling in [Today, Today + 2 Days]
        $workAnniversaries = Employee::with('departmentRel', 'designationRel')->get()->filter(function ($emp) use ($startDate, $endDate) {
            if (!$emp->joining_date) return false;
            $annivThisYear = \Carbon\Carbon::parse($emp->joining_date)->year(now()->year)->startOfDay();
            $annivNextYear = \Carbon\Carbon::parse($emp->joining_date)->year(now()->year + 1)->startOfDay();
            
            if ($annivThisYear->between($startDate, $endDate)) {
                $emp->anniversary_years = now()->year - \Carbon\Carbon::parse($emp->joining_date)->year;
                return true;
            }
            if ($annivNextYear->between($startDate, $endDate)) {
                $emp->anniversary_years = (now()->year + 1) - \Carbon\Carbon::parse($emp->joining_date)->year;
                return true;
            }
            return false;
        })->sortBy(function ($emp) {
            return \Carbon\Carbon::parse($emp->joining_date)->day;
        })->values();

        // Fetch all active employees for the interactive calendar
        $calendarEmployees = Employee::with('departmentRel')
            ->where('status', 'Active')
            ->get()
            ->map(function ($emp) {
                return [
                    'name' => $emp->name,
                    'dob' => $emp->dob,
                    'joining_date' => $emp->joining_date,
                    'department' => $emp->departmentRel->name ?? $emp->department ?? 'General',
                ];
            });

        // Define company holidays
        $companyHolidays = [
            ['date' => '2026-01-01', 'name' => "New Year's Day"],
            ['date' => '2026-01-26', 'name' => 'Republic Day'],
            ['date' => '2026-05-01', 'name' => 'Labor Day'],
            ['date' => '2026-07-15', 'name' => 'Corporate Wellness Day'],
            ['date' => '2026-07-26', 'name' => 'Mid-Year Review Holiday'],
            ['date' => '2026-08-15', 'name' => 'Independence Day'],
            ['date' => '2026-10-02', 'name' => 'Gandhi Jayanti'],
            ['date' => '2026-11-01', 'name' => 'Karnataka Rajyotsava'],
            ['date' => '2026-12-25', 'name' => 'Christmas Day'],
        ];

        $bloodGroups = ['O+', 'A+', 'B+', 'AB+', 'O-', 'A-', 'B-', 'AB-'];

        return view('admin.dashboard', compact('totalEmployees', 'activeEmployees', 'inactiveEmployees', 'terminatedEmployees', 'resignedEmployees', 'departments', 'recentEntries', 'upcomingBirthdays', 'workAnniversaries', 'bloodGroups', 'calendarEmployees', 'companyHolidays'));
    }

    public function searchBloodGroup(Request $request)
    {
        $bloodGroup = $request->get('blood_group');
        $employees = Employee::with('departmentRel')
            ->where('blood_group', $bloodGroup)
            ->get()
            ->map(function ($emp) {
                return [
                    'name' => $emp->name,
                    'status' => $emp->status,
                    'department' => $emp->departmentRel->name ?? $emp->department ?? 'N/A',
                    'blood_group' => $emp->blood_group,
                    'contact' => $emp->personal_phone ?? $emp->office_phone ?? 'N/A',
                    'initials' => collect(explode(' ', $emp->name))->map(fn($n) => mb_substr($n, 0, 1))->take(2)->join(''),
                ];
            });

        return response()->json($employees);
    }
}
