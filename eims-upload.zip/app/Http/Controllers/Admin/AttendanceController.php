<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Attendance;
use App\Models\Employee;

class AttendanceController extends Controller
{
    // Helper method to apply filters
    private function applyFilters($query, Request $request)
    {
        if ($request->filled('department_id')) {
            $query->whereHas('employee', function ($q) use ($request) {
                $q->where('department_id', $request->department_id);
            });
        }
        
        if ($request->filled('employee_id')) {
            $query->where('employee_id', $request->employee_id);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Date Filtering Logic
        $type = $request->get('date_filter_type', 'date');
        
        if ($type === 'date') {
            $date = $request->get('date', date('Y-m-d'));
            $query->where('date', $date);
        } elseif ($type === 'month') {
            $month = $request->get('month', date('m'));
            $year = $request->get('year', date('Y'));
            $query->whereYear('date', $year)->whereMonth('date', $month);
        } elseif ($type === 'year') {
            $year = $request->get('year', date('Y'));
            $query->whereYear('date', $year);
        } elseif ($type === 'custom' && $request->filled('start_date') && $request->filled('end_date')) {
            $query->whereBetween('date', [$request->start_date, $request->end_date]);
        }

        return $query;
    }

    public function index(Request $request)
    {
        $baseQuery = Attendance::with(['employee.departmentRel', 'employee.designationRel']);
        
        // Apply Filters
        $query = $this->applyFilters(clone $baseQuery, $request);
        
        // Get Results
        $attendances = $query->orderBy('date', 'desc')->orderBy('created_at', 'desc')->get();

        // Summary Statistics (calculated from the filtered dataset)
        $stats = [
            'total' => $attendances->count(),
            'present' => $attendances->where('status', 'Present')->count(),
            'absent' => $attendances->where('status', 'Absent')->count(),
            'late' => $attendances->where('status', 'Late')->count(),
            'half_day' => $attendances->where('status', 'Half-Day')->count(),
            'leave' => $attendances->where('status', 'Leave')->count()
        ];

        // Filter Options
        $departments = \App\Models\Department::all();
        $employees = Employee::where('status', 'Active')->orderBy('name')->get();

        return view('admin.attendance.index', compact('attendances', 'stats', 'departments', 'employees', 'request'));
    }

    public function export(Request $request)
    {
        $query = Attendance::with(['employee.departmentRel', 'employee.designationRel']);
        $query = $this->applyFilters($query, $request);
        $attendances = $query->orderBy('date', 'desc')->get();

        $filename = "attendance_report_" . date('Y-m-d_H-i-s') . ".csv";
        $headers = [
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=$filename",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0"
        ];

        $columns = ['Employee ID', 'Employee Name', 'Department', 'Date', 'Status', 'Check In', 'Check Out'];

        $callback = function() use($attendances, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);

            foreach ($attendances as $att) {
                fputcsv($file, [
                    $att->employee->employee_id ?? 'N/A',
                    $att->employee->name ?? 'N/A',
                    $att->employee->departmentRel->name ?? 'N/A',
                    $att->date,
                    $att->status,
                    $att->check_in ? \Carbon\Carbon::parse($att->check_in)->format('h:i A') : 'N/A',
                    $att->check_out ? \Carbon\Carbon::parse($att->check_out)->format('h:i A') : 'N/A'
                ]);
            }
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }

    public function store(Request $request)
    {
        $request->validate([
            'employee_id' => 'required|exists:employees,id',
            'date' => 'required|date',
            'status' => 'required|in:Present,Absent,Half-Day,Leave,Late',
            'check_in' => 'nullable',
            'check_out' => 'nullable',
        ]);

        Attendance::updateOrCreate(
            ['employee_id' => $request->employee_id, 'date' => $request->date],
            ['status' => $request->status, 'check_in' => $request->check_in, 'check_out' => $request->check_out]
        );

        return back()->with('success', 'Attendance recorded successfully');
    }

    public function destroy($id)
    {
        Attendance::destroy($id);
        return back()->with('success', 'Attendance record deleted');
    }
}
