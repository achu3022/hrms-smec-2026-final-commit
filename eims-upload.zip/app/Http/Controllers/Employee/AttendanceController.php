<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Attendance;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class AttendanceController extends Controller
{
    public function punchIn(Request $request)
    {
        $request->validate([
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
        ]);

        $employeeId = Auth::guard('employee')->user()->employee_id;
        $today = Carbon::today()->toDateString();

        $now = Carbon::now();
        $time = $now->format('H:i');
        $status = 'Present';
        
        if ($time > '09:20') {
            $status = 'Half-Day';
        } elseif ($time > '09:05') {
            $status = 'Late';
        }

        $attendance = Attendance::firstOrCreate(
            ['employee_id' => $employeeId, 'date' => $today],
            [
                'check_in' => $now->toTimeString(),
                'check_in_latitude' => $request->latitude,
                'check_in_longitude' => $request->longitude,
                'status' => $status,
            ]
        );

        if (!$attendance->wasRecentlyCreated && !$attendance->check_in) {
            $attendance->update([
                'check_in' => $now->toTimeString(),
                'check_in_latitude' => $request->latitude,
                'check_in_longitude' => $request->longitude,
                'status' => $status,
            ]);
        }

        return response()->json([
            'success' => true, 
            'message' => 'Punched in successfully!',
            'check_in' => Carbon::parse($attendance->check_in)->format('h:i A')
        ]);
    }

    public function punchOut(Request $request)
    {
        $request->validate([
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
        ]);

        $employeeId = Auth::guard('employee')->user()->employee_id;
        $today = Carbon::today()->toDateString();

        $attendance = Attendance::where('employee_id', $employeeId)->where('date', $today)->first();

        if (!$attendance) {
            return response()->json(['success' => false, 'message' => 'You have not punched in today.'], 400);
        }

        if ($attendance->check_out) {
            return response()->json(['success' => false, 'message' => 'Already punched out.'], 400);
        }

        $attendance->update([
            'check_out' => Carbon::now()->toTimeString(),
            'check_out_latitude' => $request->latitude,
            'check_out_longitude' => $request->longitude,
        ]);

        return response()->json([
            'success' => true, 
            'message' => 'Punched out successfully!',
            'check_out' => Carbon::parse($attendance->check_out)->format('h:i A')
        ]);
    }
}
