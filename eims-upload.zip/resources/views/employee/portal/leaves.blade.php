﻿@extends('employee.portal.layout')

@push('styles')
<style>
    /* Apply Form */
    .lv-form-card { background:#fff; border:1px solid #e2e8f0; border-radius:14px; padding:20px; margin-bottom:24px; }
    .lv-form-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
    @media(max-width:640px){ .lv-form-grid{ grid-template-columns:1fr; } }
    .lv-form-group { display:flex; flex-direction:column; gap:5px; }
    .lv-form-label { font-size:.75rem; font-weight:700; color:#475569; }
    .lv-form-input, .lv-form-textarea {
        border:1px solid #e2e8f0; border-radius:8px; padding:8px 12px;
        font-size:.85rem; color:#1e293b; background:#f8fafc; outline:none;
        transition:border-color .2s; font-family:inherit;
    }
    .lv-form-input:focus, .lv-form-textarea:focus { border-color:#6366f1; background:#fff; }
    .lv-form-textarea { resize:vertical; min-height:90px; }
    .lv-submit-btn {
        background:#2b3a67; color:#fff; border:none; border-radius:8px;
        padding:9px 22px; font-size:.85rem; font-weight:700; cursor:pointer; transition:all .2s;
        display:inline-flex; align-items:center; gap:6px;
    }
    .lv-submit-btn:hover { background:#1e293b; }

    /* Stats */
    .lv-stat-row { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:24px; }
    @media(max-width:480px){ .lv-stat-row{ grid-template-columns:1fr 1fr; } }
    .lv-stat-card {
        background:#fff; border:1px solid #e2e8f0; border-radius:12px;
        padding:14px; display:flex; flex-direction:column; gap:4px; text-align:center; transition:all .2s;
    }
    .lv-stat-card:hover { box-shadow:0 4px 12px rgba(0,0,0,.05); transform:translateY(-1px); }
    .lv-stat-val  { font-size:1.6rem; font-weight:800; color:#1e293b; line-height:1; }
    .lv-stat-lbl  { font-size:.65rem; font-weight:700; color:#94a3b8; text-transform:uppercase; letter-spacing:.4px; }

    /* History Table */
    .lv-table { width:100%; border-collapse:collapse; }
    .lv-table th { background:#f8fafc; color:#64748b; font-size:.7rem; font-weight:700; text-transform:uppercase; letter-spacing:.4px; padding:9px 14px; text-align:left; border-bottom:1px solid #e2e8f0; }
    .lv-table td { padding:11px 14px; font-size:.82rem; border-bottom:1px solid #f1f5f9; color:#374151; }
    .lv-table tr:last-child td { border-bottom:none; }
    .lv-table tr:hover td { background:#f8fafc; }
    .lv-pill { display:inline-flex; align-items:center; gap:3px; font-size:.68rem; font-weight:700; padding:2px 9px; border-radius:5px; }
    .pill-pending  { background:#fef9c3; color:#ca8a04; }
    .pill-approved { background:#dcfce7; color:#16a34a; }
    .pill-rejected { background:#fee2e2; color:#dc2626; }
</style>
@endpush

@section('content')
<div class="mb-5">
    <h2 class="text-xl font-bold text-slate-800">My Leaves</h2>
    <p class="text-sm text-slate-400 mt-0.5">Apply for leave and view your leave history</p>
</div>

{{-- Summary Stats --}}
<div class="lv-stat-row">
    <div class="lv-stat-card">
        <div class="lv-stat-val" style="color:#ca8a04;">{{ $requests->where('status','Pending')->count() }}</div>
        <div class="lv-stat-lbl">Pending</div>
    </div>
    <div class="lv-stat-card">
        <div class="lv-stat-val" style="color:#16a34a;">{{ $requests->where('status','Approved')->count() }}</div>
        <div class="lv-stat-lbl">Approved</div>
    </div>
    <div class="lv-stat-card">
        <div class="lv-stat-val" style="color:#dc2626;">{{ $requests->where('status','Rejected')->count() }}</div>
        <div class="lv-stat-lbl">Rejected</div>
    </div>
</div>

<div class="grid grid-cols-1 xl:grid-cols-3 gap-6">

    {{-- Apply Form --}}
    <div class="lv-form-card">
        <h3 class="font-bold text-slate-800 text-sm mb-4 border-b border-slate-100 pb-3">
            <i class="fa-solid fa-paper-plane text-indigo-500 mr-1"></i> Apply for Leave
        </h3>

        @if(session('success'))
            <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-semibold rounded-lg px-4 py-3 mb-4 flex items-center gap-2">
                <i class="fa-solid fa-circle-check"></i>{{ session('success') }}
            </div>
        @endif
        @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-lg px-4 py-3 mb-4">
                @foreach($errors->all() as $e)<div class="flex items-center gap-1"><i class="fa-solid fa-circle-xmark"></i>{{ $e }}</div>@endforeach
            </div>
        @endif

        <form method="POST" action="{{ route('employee.leaves.store') }}">
            @csrf
            <div class="flex flex-col gap-4">
                <div class="lv-form-grid">
                    <div class="lv-form-group">
                        <label class="lv-form-label">From Date *</label>
                        <input type="date" name="start_date" class="lv-form-input"
                               value="{{ old('start_date') }}" required min="{{ now()->toDateString() }}">
                    </div>
                    <div class="lv-form-group">
                        <label class="lv-form-label">To Date *</label>
                        <input type="date" name="end_date" class="lv-form-input"
                               value="{{ old('end_date') }}" required min="{{ now()->toDateString() }}">
                    </div>
                </div>
                <div class="lv-form-group">
                    <label class="lv-form-label">Reason</label>
                    <textarea name="reason" class="lv-form-textarea"
                              placeholder="Briefly describe the reason...">{{ old('reason') }}</textarea>
                </div>
                <button type="submit" class="lv-submit-btn">
                    <i class="fa-solid fa-paper-plane"></i> Submit Request
                </button>
            </div>
        </form>
    </div>

    {{-- Leave History --}}
    <div class="xl:col-span-2 bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div class="flex justify-between items-center px-5 py-4 border-b border-slate-100">
            <h3 class="font-bold text-slate-800 text-sm">
                <i class="fa-solid fa-clock-rotate-left text-indigo-500 mr-1"></i> Leave History
            </h3>
            <span class="text-xs text-slate-400">{{ $requests->count() }} total requests</span>
        </div>

        @if($requests->isNotEmpty())
        <div class="overflow-x-auto">
            <table class="lv-table">
                <thead>
                    <tr>
                        <th>From</th>
                        <th>To</th>
                        <th>Days</th>
                        <th>Reason</th>
                        <th>Applied On</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($requests as $req)
                    <tr>
                        <td class="font-semibold">{{ \Carbon\Carbon::parse($req->start_date)->format('d M Y') }}</td>
                        <td>{{ \Carbon\Carbon::parse($req->end_date)->format('d M Y') }}</td>
                        <td class="font-bold text-indigo-600">{{ $req->total_days }}</td>
                        <td class="text-slate-500 max-w-[200px] truncate">{{ $req->reason ?? '—' }}</td>
                        <td class="text-slate-400">{{ $req->created_at->format('d M Y') }}</td>
                        <td>
                            <span class="lv-pill
                                @if($req->status==='Approved') pill-approved
                                @elseif($req->status==='Rejected') pill-rejected
                                @else pill-pending @endif">
                                @if($req->status==='Approved')<i class="fa-solid fa-circle-check"></i>
                                @elseif($req->status==='Rejected')<i class="fa-solid fa-circle-xmark"></i>
                                @else<i class="fa-solid fa-clock"></i>@endif
                                {{ $req->status }}
                            </span>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @else
            <div class="text-center py-14 text-slate-400">
                <i class="fa-regular fa-calendar-xmark text-4xl mb-3 block"></i>
                <p class="text-sm font-semibold">No leave requests yet.</p>
                <p class="text-xs mt-1">Submit a leave request using the form on the left.</p>
            </div>
        @endif
    </div>
</div>
@endsection
