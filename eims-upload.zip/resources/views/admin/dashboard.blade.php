﻿@extends('layouts.admin')

@section('content')
<!-- Custom Google Fonts for Twisty style dashboard -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
    /* Scope the styling specifically for the Twisty theme */
    .twisty-theme {
        font-family: 'Inter', sans-serif;
        color: #2b3a4a;
        background-color: #f4f6fa;
        min-height: 100vh;
        padding-top: 10px;
    }

    /* Tab styles matching Twisty header nav */
    .twisty-nav-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        padding-bottom: 15px;
    }
    .twisty-tabs {
        display: flex;
        gap: 30px;
    }
    .twisty-tab-link {
        font-size: 1.05rem;
        font-weight: 600;
        color: #8c9ba5;
        background: none;
        border: none;
        padding: 5px 0;
        position: relative;
        cursor: pointer;
        transition: color 0.2s ease;
    }
    .twisty-tab-link:hover {
        color: #1e293b;
    }
    .twisty-tab-link.active {
        color: #1e293b;
    }
    .twisty-tab-link.active::after {
        content: '';
        position: absolute;
        bottom: -16px;
        left: 0;
        right: 0;
        height: 3px;
        background-color: #4f46e5; /* Twisty bright orange-red */
        border-radius: 2px;
    }

    /* Twisty Card styling */
    .twisty-card {
        background: #ffffff;
        border-radius: 24px;
        box-shadow: 0 10px 30px rgba(138, 155, 168, 0.06);
        border: 1px solid rgba(226, 232, 240, 0.8);
        padding: 24px;
        margin-bottom: 24px;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        overflow: hidden;
    }
    .twisty-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 16px 40px rgba(138, 155, 168, 0.12);
    }
    .twisty-card-title {
        font-size: 1.3rem;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 8px;
    }
    .twisty-card-subtitle {
        font-size: 0.85rem;
        color: #8c9ba5;
        margin-bottom: 20px;
    }

    /* Quick Actions styles */
    .actions-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-bottom: 10px;
    }
    .action-card {
        background: #fafbfc;
        border: 1px solid #f0f3f6;
        border-radius: 20px;
        padding: 20px;
        display: flex;
        align-items: center;
        gap: 16px;
        text-decoration: none !important;
        transition: all 0.25s ease;
    }
    .action-card:hover {
        background: #ffffff;
        border-color: #4f46e5;
        box-shadow: 0 8px 24px rgba(138, 155, 168, 0.08);
        transform: translateY(-2px);
    }
    .action-icon-circle {
        width: 48px;
        height: 48px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        color: #ffffff;
    }
    .action-text {
        display: flex;
        flex-direction: column;
    }
    .action-title {
        font-size: 0.95rem;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 2px;
    }
    .action-desc {
        font-size: 0.75rem;
        color: #8c9ba5;
    }

    /* Celebrations styles */
    .celebrations-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    .celebration-tabs {
        display: flex;
        gap: 10px;
        background: #fafbfc;
        border: 1px solid #f0f3f6;
        padding: 4px;
        border-radius: 12px;
    }
    .celebration-tab-btn {
        background: none;
        border: none;
        font-size: 0.8rem;
        font-weight: 700;
        color: #8c9ba5;
        padding: 6px 14px;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    .celebration-tab-btn:hover {
        color: #1e293b;
    }
    .celebration-tab-btn.active {
        color: #4f46e5;
        background: #ffffff;
        box-shadow: 0 2px 6px rgba(138, 155, 168, 0.1);
    }
    .celebration-list {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }
    .celebration-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 14px 16px;
        background: #fafbfc;
        border: 1px solid #f0f3f6;
        border-radius: 16px;
        transition: all 0.2s ease;
    }
    .celebration-item:hover {
        background: #ffffff;
        box-shadow: 0 4px 12px rgba(138, 155, 168, 0.05);
        border-color: #e2e8f0;
    }
    .celebration-profile {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .celebration-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 0.9rem;
    }
    .celebration-info {
        display: flex;
        flex-direction: column;
    }
    .celebration-name {
        font-size: 0.9rem;
        font-weight: 700;
        color: #1e293b;
    }
    .celebration-subtitle {
        font-size: 0.75rem;
        color: #8c9ba5;
    }
    .celebration-badge {
        font-size: 0.75rem;
        font-weight: 700;
        padding: 4px 10px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    .celebration-badge.birthday {
        background: #fff5f5;
        color: #e03131;
    }
    .celebration-badge.anniversary {
        background: #e6fcf5;
        color: #0ca678;
    }

    /* Proposal Progress Replica style */
    .progress-summary-grid {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        gap: 15px;
        margin-bottom: 25px;
    }
    .progress-summary-col {
        border-right: 1px solid #e2e8f0;
        padding-right: 10px;
    }
    .progress-summary-col:last-child {
        border-right: none;
    }
    .progress-summary-label {
        font-size: 0.8rem;
        color: #8c9ba5;
        margin-bottom: 5px;
    }
    .progress-summary-val {
        font-size: 1.8rem;
        font-weight: 700;
        color: #1e293b;
    }
    .progress-visual-bars {
        display: flex;
        align-items: flex-end;
        gap: 4px;
        height: 60px;
        margin-top: 20px;
        overflow: hidden;
    }
    .progress-visual-bar {
        flex: 1;
        background: #f1f5f9;
        border-radius: 4px;
        min-height: 4px;
    }
    .progress-visual-bar.orange {
        background: #4f46e5;
    }
    .progress-visual-bar.dark {
        background: #1e293b;
    }

    /* Recent Onboardings Item styling (Your Recent Projects style) */
    .twisty-list-container {
        display: flex;
        flex-direction: column;
        gap: 16px;
    }
    .twisty-list-item {
        background: #fafbfc;
        border: 1px solid #f0f3f6;
        border-radius: 20px;
        padding: 16px;
        display: flex;
        align-items: center;
        gap: 16px;
        transition: all 0.2s ease;
    }
    .twisty-list-item:hover {
        background: #ffffff;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03);
        border-color: #e2e8f0;
    }
    .item-icon-wrapper {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        font-weight: 700;
    }
    .item-content {
        flex: 1;
    }
    .item-title-row {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 4px;
    }
    .item-title {
        font-size: 0.95rem;
        font-weight: 700;
        color: #1e293b;
    }
    .item-badge {
        font-size: 0.7rem;
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 8px;
    }
    .item-badge.paid {
        background: #e6fcf5;
        color: #0ca678;
    }
    .item-badge.unpaid {
        background: #fff0f6;
        color: #d6336c;
    }
    .item-details {
        font-size: 0.8rem;
        color: #8c9ba5;
        margin-bottom: 6px;
        line-height: 1.4;
    }
    .item-meta {
        font-size: 0.75rem;
        color: #a0aec0;
        display: flex;
        gap: 15px;
    }
    .item-meta-item {
        display: flex;
        align-items: center;
        gap: 4px;
    }
    .item-arrow {
        color: #a0aec0;
        cursor: pointer;
        padding: 5px;
        border-radius: 50%;
        transition: all 0.2s ease;
    }
    .item-arrow:hover {
        background: #edf2f7;
        color: #1e293b;
    }

    /* Blood Group Search form styling */
    .blood-search-form {
        display: flex;
        gap: 15px;
        margin-bottom: 30px;
        align-items: center;
        flex-wrap: wrap;
    }
    .blood-select-wrapper {
        flex: 1;
        min-width: 200px;
        position: relative;
    }
    .blood-select {
        width: 100%;
        border-radius: 16px;
        border: 1px solid #cbd5e1;
        padding: 12px 18px;
        font-size: 0.95rem;
        font-weight: 600;
        color: #1e293b;
        background-color: #ffffff;
        outline: none;
        appearance: none;
        cursor: pointer;
        transition: border-color 0.2s ease;
    }
    .blood-select:focus {
        border-color: #4f46e5;
    }
    .blood-select-wrapper::after {
        content: '\f078';
        font-family: 'Font Awesome 6 Free';
        font-weight: 900;
        position: absolute;
        right: 18px;
        top: 50%;
        transform: translateY(-50%);
        color: #8c9ba5;
        pointer-events: none;
    }
    .blood-btn {
        background: #1e293b;
        color: #ffffff;
        border: none;
        border-radius: 16px;
        padding: 12px 28px;
        font-weight: 700;
        font-size: 0.95rem;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .blood-btn:hover {
        background: #4f46e5;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.2);
    }

    /* Blood Group list results layout */
    .blood-results-title {
        font-size: 1.1rem;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .blood-drop-icon {
        color: #e03131;
    }
    .blood-employee-list {
        display: grid;
        grid-template-columns: 1fr;
        gap: 15px;
    }
    @media (min-width: 768px) {
        .blood-employee-list {
            grid-template-columns: 1fr 1fr;
        }
    }
    .blood-employee-card {
        background: #fafbfc;
        border: 1px solid #f0f3f6;
        border-radius: 20px;
        padding: 20px;
        display: flex;
        gap: 16px;
        align-items: center;
        transition: all 0.2s ease;
        position: relative;
    }
    .blood-employee-card:hover {
        background: #ffffff;
        box-shadow: 0 8px 24px rgba(138, 155, 168, 0.1);
        border-color: #e2e8f0;
    }
    .blood-badge-avatar {
        width: 52px;
        height: 52px;
        border-radius: 16px;
        background: #fff5f5;
        border: 1px solid #ffe3e3;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 1.1rem;
        color: #e03131;
    }
    .blood-emp-details {
        flex: 1;
    }
    .blood-emp-name-row {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 4px;
        flex-wrap: wrap;
    }
    .blood-emp-name {
        font-size: 1rem;
        font-weight: 700;
        color: #1e293b;
    }
    .blood-emp-status-badge {
        font-size: 0.65rem;
        font-weight: 700;
        padding: 2px 6px;
        border-radius: 6px;
        text-transform: uppercase;
    }
    .status-active {
        background: #ebfbee;
        color: #2b8a3e;
    }
    .status-inactive {
        background: #fff5f5;
        color: #c92a2a;
    }
    .blood-emp-info-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 4px;
        margin-top: 8px;
    }
    .blood-emp-info-item {
        font-size: 0.8rem;
        color: #8c9ba5;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .blood-emp-info-item i {
        width: 14px;
        color: #a0aec0;
    }

    /* Empty state styling */
    .empty-state {
        text-align: center;
        padding: 40px 20px;
        color: #8c9ba5;
    }
    .empty-state-icon {
        font-size: 3rem;
        color: #cbd5e1;
        margin-bottom: 15px;
    }
    .empty-state-text {
        font-size: 0.95rem;
        font-weight: 500;
    }
    
    /* Loading spinner style */
    .loading-spinner {
        display: none;
        justify-content: center;
        align-items: center;
        padding: 40px;
    }
    
    /* Micro-animation transitions */
    .fade-in {
        animation: fadeIn 0.35s ease forwards;
    }
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Calendar day grid cells */
    .calendar-day-cell {
        aspect-ratio: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        position: relative;
        transition: all 0.2s ease;
        color: #4a5568;
    }
    .calendar-day-cell:hover {
        background-color: #edf2f7;
    }
    .calendar-day-cell.other-month {
        color: #cbd5e1;
        pointer-events: none;
    }
    .calendar-day-cell.today {
        border: 2px solid #1e293b;
    }
    .calendar-day-cell.has-holiday {
        background-color: #fff5f5 !important;
        color: #e03131 !important;
        border: 1px solid #ffc9c9;
    }
    .calendar-day-cell.has-holiday:hover {
        background-color: #ffe3e3 !important;
    }
    .calendar-day-cell.has-birthday {
        background-color: #fff9db !important;
        color: #f08c00 !important;
        border: 1px solid #ffe066;
    }
    .calendar-day-cell.has-birthday:hover {
        background-color: #fff3bf !important;
    }
    .calendar-day-cell.has-anniversary {
        background-color: #ebfbee !important;
        color: #2b8a3e !important;
        border: 1px solid #b2f2bb;
    }
    .calendar-day-cell.has-anniversary:hover {
        background-color: #d3f9d8 !important;
    }
    .legend-dot {
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
    }
    
    .event-item-right {
        font-size: 0.7rem;
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 6px;
    }

    /* Custom Popover Container Positioned Above Date */
    .calendar-event-popover {
        position: absolute;
        width: 270px;
        height: auto;
        max-height: 240px;
        background: #ffffff;
        border-radius: 18px;
        box-shadow: 0 12px 36px rgba(28, 43, 58, 0.15);
        border: 1px solid rgba(226, 232, 240, 0.9);
        z-index: 100;
        padding: 16px;
        display: none;
        box-sizing: border-box;
    }
    .popover-header {
        border-bottom: 1px solid #f0f3f6;
        padding-bottom: 8px;
        margin-bottom: 10px;
    }
    .popover-close-btn {
        background: none;
        border: none;
        font-size: 1.2rem;
        color: #8c9ba5;
        cursor: pointer;
        padding: 0;
        line-height: 1;
        transition: color 0.2s ease;
    }
    .popover-close-btn:hover {
        color: #4f46e5;
    }
    .popover-body {
        max-height: 170px;
        overflow-y: auto;
    }
    
    /* Opacity only fade-in transition to prevent keyframes animation transform conflicts */
    .popover-fade-in {
        animation: popoverFadeIn 0.25s ease forwards;
    }
    @keyframes popoverFadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    /* Calendar Event items inside Popover */
    .calendar-event-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 12px;
        border-radius: 12px;
        background: #fafbfc;
        border: 1px solid #f0f3f6;
        margin-bottom: 8px;
        transition: all 0.2s ease;
    }
    .calendar-event-item:last-child {
        margin-bottom: 0;
    }
    .event-item-left {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
    }
    .event-item-icon {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.8rem;
    }
    .event-item-info {
        display: flex;
        flex-direction: column;
        min-width: 0;
    }
    .event-item-title {
        font-size: 0.8rem;
        font-weight: 700;
        color: #1e293b;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .event-item-subtitle {
        font-size: 0.7rem;
        color: #8c9ba5;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .event-item-right {
        font-size: 0.7rem;
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 6px;
    }

    /* Employee Status Summary Grid */
    .status-summary-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 16px;
    }
    @media (min-width: 768px) {
        .status-summary-grid {
            grid-template-columns: repeat(5, 1fr);
        }
    }
    .status-metric-card {
        background: #fafbfc;
        border: 1px solid #f0f3f6;
        border-radius: 20px;
        padding: 20px 16px;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        gap: 12px;
        transition: all 0.25s ease;
    }
    .status-metric-card:hover {
        background: #ffffff;
        border-color: #4f46e5;
        box-shadow: 0 8px 24px rgba(138, 155, 168, 0.08);
        transform: translateY(-2px);
    }
    .status-metric-icon {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
    }
    .status-metric-info {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }
    .status-metric-label {
        font-size: 0.72rem;
        font-weight: 700;
        color: #8c9ba5;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .status-metric-value {
        font-size: 1.6rem;
        font-weight: 800;
        color: #1e293b;
    }
    
    .bg-primary-subtle { background-color: #eef2ff !important; }
    .bg-success-subtle { background-color: #ebfbee !important; }
    .bg-warning-subtle { background-color: #fff9db !important; }
    .bg-danger-subtle { background-color: #fff5f5 !important; }
    .bg-secondary-subtle { background-color: #f1f3f5 !important; }
</style>

<div class="twisty-theme">
    <!-- Redesigned Top Header Menu -->
    <div class="twisty-nav-container">
        <div class="twisty-tabs">
            <button class="twisty-tab-link active" onclick="switchTab(event, 'overview-tab')">Overview</button>
            <button class="twisty-tab-link" onclick="switchTab(event, 'blood-group-tab')">Blood Group</button>
        </div>
        <div class="text-muted small fw-semibold">
            <i class="fa fa-calendar me-1 text-primary"></i> {{ date('F d, Y') }}
        </div>
    </div>

    <!-- OVERVIEW TAB CONTENT -->
    <div id="overview-tab" class="tab-content fade-in">
        <div class="row">
            <!-- Left Side Column (Wider Widgets) -->
            <div class="col-lg-8">
                <!-- Employee Status Card -->
                <div class="twisty-card">
                    <div class="twisty-card-title">Employee Status</div>
                    <div class="twisty-card-subtitle">Overview of team structure and employment states</div>
                    
                    <div class="status-summary-grid">
                        <div class="status-metric-card">
                            <div class="status-metric-icon bg-primary-subtle text-primary">
                                <i class="fa fa-users"></i>
                            </div>
                            <div class="status-metric-info">
                                <span class="status-metric-label">Total Employees</span>
                                <span class="status-metric-value">{{ $totalEmployees }}</span>
                            </div>
                        </div>
                        <div class="status-metric-card">
                            <div class="status-metric-icon bg-success-subtle text-success">
                                <i class="fa fa-user-check"></i>
                            </div>
                            <div class="status-metric-info">
                                <span class="status-metric-label">Active</span>
                                <span class="status-metric-value">{{ $activeEmployees }}</span>
                            </div>
                        </div>
                        <div class="status-metric-card">
                            <div class="status-metric-icon bg-warning-subtle text-warning">
                                <i class="fa fa-user-minus"></i>
                            </div>
                            <div class="status-metric-info">
                                <span class="status-metric-label">Inactive</span>
                                <span class="status-metric-value">{{ $inactiveEmployees }}</span>
                            </div>
                        </div>
                        <div class="status-metric-card">
                            <div class="status-metric-icon bg-danger-subtle text-danger">
                                <i class="fa fa-user-xmark"></i>
                            </div>
                            <div class="status-metric-info">
                                <span class="status-metric-label">Terminated</span>
                                <span class="status-metric-value">{{ $terminatedEmployees }}</span>
                            </div>
                        </div>
                        <div class="status-metric-card">
                            <div class="status-metric-icon bg-secondary-subtle text-secondary">
                                <i class="fa fa-user-slash"></i>
                            </div>
                            <div class="status-metric-info">
                                <span class="status-metric-label">Resigned</span>
                                <span class="status-metric-value">{{ $resignedEmployees }}</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Upcoming Celebrations Widget -->
                <div class="twisty-card">
                    <div class="celebrations-header">
                        <div>
                            <div class="twisty-card-title">Upcoming Celebrations</div>
                            <div class="twisty-card-subtitle">Staff events happening this month</div>
                        </div>
                        <div class="celebration-tabs">
                            <button id="btnBirthdays" class="celebration-tab-btn active" onclick="switchCelebrationTab('birthdays')">Birthdays</button>
                            <button id="btnAnniversaries" class="celebration-tab-btn" onclick="switchCelebrationTab('anniversaries')">Anniversaries</button>
                        </div>
                    </div>

                    <!-- Birthdays List -->
                    <div id="celebrationBirthdays" class="celebration-list fade-in">
                        @forelse($upcomingBirthdays as $emp)
                            @php
                                $initials = collect(explode(' ', $emp->name))->map(fn($n) => mb_substr($n, 0, 1))->take(2)->join('');
                            @endphp
                            <div class="celebration-item">
                                <div class="celebration-profile">
                                    <div class="celebration-avatar" style="background-color: #fff0f6; color: #d6336c;">
                                        {{ $initials }}
                                    </div>
                                    <div class="celebration-info">
                                        <span class="celebration-name">{{ $emp->name }}</span>
                                        <span class="celebration-subtitle">{{ $emp->designationRel->name ?? $emp->designation ?? 'N/A' }} â€¢ {{ $emp->departmentRel->name ?? $emp->department ?? 'General' }} â€¢ Status: <span class="{{ $emp->status === 'Active' ? 'text-success' : 'text-danger' }} fw-bold">{{ $emp->status }}</span></span>
                                    </div>
                                </div>
                                <div class="celebration-badge birthday">
                                    <i class="fa fa-cake-candles"></i> {{ \Carbon\Carbon::parse($emp->dob)->format('M d') }}
                                </div>
                            </div>
                        @empty
                            <div class="text-center text-muted py-3">No birthdays in the next 2 days.</div>
                        @endforelse
                    </div>

                    <!-- Anniversaries List -->
                    <div id="celebrationAnniversaries" class="celebration-list fade-in" style="display: none;">
                        @forelse($workAnniversaries as $emp)
                            @php
                                $initials = collect(explode(' ', $emp->name))->map(fn($n) => mb_substr($n, 0, 1))->take(2)->join('');
                                $years = $emp->anniversary_years;
                            @endphp
                            <div class="celebration-item">
                                <div class="celebration-profile">
                                    <div class="celebration-avatar" style="background-color: #e6fcf5; color: #0ca678;">
                                        {{ $initials }}
                                    </div>
                                    <div class="celebration-info">
                                        <span class="celebration-name">{{ $emp->name }}</span>
                                        <span class="celebration-subtitle">Joined on {{ \Carbon\Carbon::parse($emp->joining_date)->format('M d, Y') }} â€¢ {{ $emp->departmentRel->name ?? $emp->department ?? 'General' }} â€¢ Status: <span class="{{ $emp->status === 'Active' ? 'text-success' : 'text-danger' }} fw-bold">{{ $emp->status }}</span></span>
                                    </div>
                                </div>
                                <div class="celebration-badge anniversary">
                                    <i class="fa fa-award"></i> {{ $years > 0 ? $years . ' Yr' . ($years > 1 ? 's' : '') : 'New Joiner' }}
                                </div>
                            </div>
                        @empty
                            <div class="text-center text-muted py-3">No work anniversaries in the next 2 days.</div>
                        @endforelse
                    </div>
                </div>
            </div>

            <!-- Right Side Column (Narrower Widgets) -->
            <div class="col-lg-4">
                <!-- Events Calendar Card -->
                <div class="twisty-card" style="position: relative;">
                    <div class="d-flex justify-content-between align-items-center mb-3 border-bottom pb-2">
                        <div class="twisty-card-title mb-0"><i class="fa fa-calendar-days text-primary me-2"></i>Events Calendar</div>
                        <div class="d-flex gap-2 align-items-center">
                            <button onclick="prevMonth()" class="btn btn-sm btn-light py-0 px-2" style="border-radius: 8px;"><i class="fa fa-chevron-left"></i></button>
                            <span id="calendarMonthYear" class="fw-bold text-dark" style="font-size: 0.9rem; min-width: 90px; text-align: center;"></span>
                            <button onclick="nextMonth()" class="btn btn-sm btn-light py-0 px-2" style="border-radius: 8px;"><i class="fa fa-chevron-right"></i></button>
                        </div>
                    </div>
                    
                    <!-- Weekdays Header -->
                    <div class="d-grid text-center text-muted fw-bold mb-2" style="grid-template-columns: repeat(7, 1fr); font-size: 0.75rem; letter-spacing: 0.5px;">
                        <span>S</span><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span>
                    </div>

                    <!-- Days Grid -->
                    <div id="calendarDaysGrid" class="d-grid text-center gap-1 mb-3" style="grid-template-columns: repeat(7, 1fr);">
                        <!-- Days will be dynamically injected by JS -->
                    </div>

                    <!-- Calendar Legend -->
                    <div class="d-flex justify-content-center gap-3 pt-2 border-top" style="font-size: 0.7rem; font-weight: 600;">
                        <span class="d-flex align-items-center gap-1"><span class="legend-dot" style="background-color: #f08c00;"></span>Birthday</span>
                        <span class="d-flex align-items-center gap-1"><span class="legend-dot" style="background-color: #2b8a3e;"></span>Anniversary</span>
                        <span class="d-flex align-items-center gap-1"><span class="legend-dot" style="background-color: #e03131;"></span>Holiday</span>
                    </div>

                    <!-- Custom Calendar Event Popover -->
                    <div id="calendarEventPopover" class="calendar-event-popover popover-fade-in" style="display: none;">
                        <div class="popover-header d-flex justify-content-between align-items-center">
                            <span id="popoverTitle" class="fw-bold text-dark" style="font-size: 0.85rem;">Events</span>
                            <button onclick="closePopover()" class="popover-close-btn">&times;</button>
                        </div>
                        <div id="popoverBody" class="popover-body">
                            <!-- Injected by JS -->
                        </div>
                    </div>
                </div>

                <!-- Status distribution removed -->
            </div>
        </div>
    </div>

    <!-- BLOOD GROUP TAB CONTENT -->
    <div id="blood-group-tab" class="tab-content fade-in" style="display: none;">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="twisty-card">
                    <div class="twisty-card-title">Blood Group Directory</div>
                    <div class="twisty-card-subtitle">Search for employees by their blood group types</div>

                    <!-- Search Form -->
                    <div class="blood-search-form">
                        <div class="blood-select-wrapper">
                            <select id="bloodGroupSelect" class="blood-select">
                                <option value="" disabled selected>Select blood group...</option>
                                @foreach($bloodGroups as $group)
                                    <option value="{{ $group }}">{{ $group }}</option>
                                @endforeach
                            </select>
                        </div>
                        <button onclick="performBloodGroupSearch()" class="blood-btn">
                            <i class="fa fa-magnifying-glass"></i> Search
                        </button>
                    </div>

                    <!-- Loading Spinner -->
                    <div id="searchSpinner" class="loading-spinner">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>

                    <!-- Search Results -->
                    <div id="resultsContainer">
                        <!-- Default empty state -->
                        <div class="empty-state">
                            <div class="empty-state-icon">
                                <i class="fa-solid fa-droplet text-muted opacity-50"></i>
                            </div>
                            <div class="empty-state-text">Select a blood group type from the dropdown and click "Search" to view matching employees.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Tab switching function
    function switchTab(evt, tabId) {
        // Get all elements with class="tab-content" and hide them
        const tabContents = document.getElementsByClassName("tab-content");
        for (let i = 0; i < tabContents.length; i++) {
            tabContents[i].style.display = "none";
        }

        // Get all elements with class="twisty-tab-link" and remove the class "active"
        const tabLinks = document.getElementsByClassName("twisty-tab-link");
        for (let i = 0; i < tabLinks.length; i++) {
            tabLinks[i].classList.remove("active");
        }

        // Show the current tab, and add an "active" class to the button that opened the tab
        document.getElementById(tabId).style.display = "block";
        evt.currentTarget.classList.add("active");
    }

    // Switch celebrations tab
    function switchCelebrationTab(type) {
        const birthdaysEl = document.getElementById('celebrationBirthdays');
        const anniversariesEl = document.getElementById('celebrationAnniversaries');
        const btnBday = document.getElementById('btnBirthdays');
        const btnAnniv = document.getElementById('btnAnniversaries');

        if (type === 'birthdays') {
            birthdaysEl.style.display = 'flex';
            anniversariesEl.style.display = 'none';
            btnBday.classList.add('active');
            btnAnniv.classList.remove('active');
        } else {
            birthdaysEl.style.display = 'none';
            anniversariesEl.style.display = 'flex';
            btnBday.classList.remove('active');
            btnAnniv.classList.add('active');
        }
    }

    // Click trigger for CSV import shortcut
    function triggerImport(e) {
        // Check if there is an import element or modal we can click in the employees index
        // Since we link directly with a URL query ?show_import=1, the employees index page can open the import dialog.
        // Let's proceed with default navigation.
    }

    // AJAX Blood Group Search
    function performBloodGroupSearch() {
        const selectEl = document.getElementById('bloodGroupSelect');
        const bloodGroup = selectEl.value;
        if (!bloodGroup) {
            Swal.fire({
                icon: 'warning',
                title: 'Selection Required',
                text: 'Please select a blood group before searching.',
                confirmButtonColor: '#4f46e5'
            });
            return;
        }

        const resultsContainer = document.getElementById('resultsContainer');
        const spinner = document.getElementById('searchSpinner');

        // Show spinner, hide results
        resultsContainer.innerHTML = '';
        spinner.style.display = 'flex';

        // Perform GET request
        fetch(`/admin/dashboard/blood-group?blood_group=${encodeURIComponent(bloodGroup)}`, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            spinner.style.display = 'none';

            if (data.length === 0) {
                resultsContainer.innerHTML = `
                    <div class="empty-state fade-in">
                        <div class="empty-state-icon">
                            <i class="fa-solid fa-circle-exclamation text-warning"></i>
                        </div>
                        <div class="empty-state-text">No employees found with blood group <strong>${bloodGroup}</strong>.</div>
                    </div>
                `;
                return;
            }

            // Render matching list
            let listHtml = `
                <div class="blood-results-title fade-in">
                    <i class="fa-solid fa-droplet blood-drop-icon"></i>
                    <span>Matching Employees for Blood Group ${bloodGroup} (${data.length})</span>
                </div>
                <div class="blood-employee-list">
            `;

            data.forEach(emp => {
                const statusClass = emp.status.toLowerCase() === 'active' ? 'status-active' : 'status-inactive';
                listHtml += `
                    <div class="blood-employee-card fade-in">
                        <div class="blood-badge-avatar">
                            <span class="small" style="font-size:0.5rem; text-transform:uppercase; font-weight:700; color: #4f46e5; display:block; margin-bottom: 2px;">Group</span>
                            <span>${emp.blood_group}</span>
                        </div>
                        <div class="blood-emp-details">
                            <div class="blood-emp-name-row">
                                <span class="blood-emp-name">${emp.name}</span>
                                <span class="blood-emp-status-badge ${statusClass}">${emp.status}</span>
                            </div>
                            <div class="blood-emp-info-grid">
                                <div class="blood-emp-info-item">
                                    <i class="fa fa-building"></i>
                                    <span>${emp.department}</span>
                                </div>
                                <div class="blood-emp-info-item">
                                    <i class="fa fa-phone"></i>
                                    <span>${emp.contact}</span>
                                </div>
                                <div class="blood-emp-info-item">
                                    <i class="fa-solid fa-heart-pulse"></i>
                                    <span>Status: <strong>${emp.status}</strong></span>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });

            listHtml += `</div>`;
            resultsContainer.innerHTML = listHtml;
        })
        .catch(error => {
            console.error('Error fetching blood group data:', error);
            spinner.style.display = 'none';
            resultsContainer.innerHTML = `
                <div class="empty-state text-danger fade-in">
                    <div class="empty-state-icon">
                        <i class="fa-solid fa-circle-xmark"></i>
                    </div>
                    <div class="empty-state-text">Failed to retrieve search results. Please try again.</div>
                </div>
            `;
        });
    }

    // Calendar Data from PHP backend
    const employees = @json($calendarEmployees);
    const holidays = @json($companyHolidays);

    let currentDate = new Date();

    document.addEventListener("DOMContentLoaded", function() {
        renderCalendar();
    });

    function renderCalendar() {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();

        // Update Header Month/Year
        const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        document.getElementById("calendarMonthYear").innerText = `${monthNames[month]} ${year}`;

        // Get grid container
        const grid = document.getElementById("calendarDaysGrid");
        grid.innerHTML = "";

        // First day of the month index (0 = Sun, 1 = Mon...)
        const firstDayIndex = new Date(year, month, 1).getDay();

        // Last day of the current month
        const lastDay = new Date(year, month + 1, 0).getDate();

        // Last day of the previous month
        const prevLastDay = new Date(year, month, 0).getDate();

        // Total calendar cells (6 rows * 7 columns = 42)
        const totalCells = 42;

        let dayCounter = 1;
        let nextMonthCounter = 1;

        for (let i = 0; i < totalCells; i++) {
            const cell = document.createElement("div");
            
            if (i < firstDayIndex) {
                // Previous month day cell
                const prevDay = prevLastDay - firstDayIndex + i + 1;
                cell.className = "calendar-day-cell other-month";
                cell.innerText = prevDay;
            } else if (dayCounter <= lastDay) {
                // Current month day cell
                const currentDay = dayCounter;
                cell.className = "calendar-day-cell";
                cell.innerText = currentDay;

                // Check if it is today
                const today = new Date();
                if (today.getDate() === currentDay && today.getMonth() === month && today.getFullYear() === year) {
                    cell.classList.add("today");
                }

                // Gather events for this day
                const dayEvents = getDayEvents(year, month, currentDay);
                if (dayEvents.length > 0) {
                    // Check types of events to decide cell color
                    const hasHoliday = dayEvents.some(e => e.type === 'holiday');
                    const hasBirthday = dayEvents.some(e => e.type === 'birthday');
                    const hasAnniversary = dayEvents.some(e => e.type === 'anniversary');

                    // Prioritize color classes: holiday (red) > birthday (orange) > anniversary (green)
                    if (hasHoliday) {
                        cell.classList.add("has-holiday");
                    } else if (hasBirthday) {
                        cell.classList.add("has-birthday");
                    } else if (hasAnniversary) {
                        cell.classList.add("has-anniversary");
                    }

                    // Click event triggers popover positioned above the calendar cell
                    cell.addEventListener("click", (event) => {
                        event.stopPropagation();
                        openEventsPopover(year, month, currentDay, dayEvents, cell);
                    });
                }

                dayCounter++;
            } else {
                // Next month day cell
                cell.className = "calendar-day-cell other-month";
                cell.innerText = nextMonthCounter;
                nextMonthCounter++;
            }

            grid.appendChild(cell);
        }
    }

    function prevMonth() {
        closePopover();
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar();
    }

    function nextMonth() {
        closePopover();
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar();
    }

    // Get all events on a particular day (Sundays are automatically holidays)
    function getDayEvents(year, month, day) {
        const events = [];

        // Check if the day is a Sunday (0-indexed local day)
        const dateObj = new Date(year, month, day);
        const dayOfWeek = dateObj.getDay(); // 0 = Sunday

        if (dayOfWeek === 0) {
            events.push({
                type: 'holiday',
                title: 'Sunday Holiday',
                subtitle: 'Weekly Off-Day',
                icon: 'fa-umbrella-beach',
                iconBg: '#fff5f5',
                iconColor: '#e03131',
                dateLabel: 'Holiday'
            });
        }

        // 1. Birthdays
        employees.forEach(emp => {
            if (emp.dob) {
                const parts = emp.dob.split('-');
                const dobMonth = parseInt(parts[1], 10) - 1;
                const dobDay = parseInt(parts[2], 10);
                if (dobMonth === month && dobDay === day) {
                    events.push({
                        type: 'birthday',
                        title: `${emp.name} (Birthday)`,
                        subtitle: `${emp.department} Department`,
                        icon: 'fa-cake-candles',
                        iconBg: '#fff9db',
                        iconColor: '#f08c00',
                        dateLabel: 'Birthday'
                    });
                }
            }
        });

        // 2. Anniversaries
        employees.forEach(emp => {
            if (emp.joining_date) {
                const parts = emp.joining_date.split('-');
                const joinYear = parseInt(parts[0], 10);
                const joinMonth = parseInt(parts[1], 10) - 1;
                const joinDay = parseInt(parts[2], 10);
                if (joinMonth === month && joinDay === day) {
                    const yrs = year - joinYear;
                    events.push({
                        type: 'anniversary',
                        title: `${emp.name} (Anniversary)`,
                        subtitle: `Joined ${joinYear} â€¢ ${emp.department}`,
                        icon: 'fa-star',
                        iconBg: '#ebfbee',
                        iconColor: '#2b8a3e',
                        dateLabel: yrs > 0 ? `${yrs} Yr${yrs > 1 ? 's' : ''}` : 'Joined'
                    });
                }
            }
        });

        // 3. Static Holidays (timezone safe via string splitting)
        holidays.forEach(holiday => {
            const parts = holiday.date.split('-');
            const holMonth = parseInt(parts[1], 10) - 1;
            const holDay = parseInt(parts[2], 10);
            if (holMonth === month && holDay === day) {
                const exists = events.some(e => e.title === holiday.name);
                if (!exists) {
                    events.push({
                        type: 'holiday',
                        title: holiday.name,
                        subtitle: 'Company Holiday',
                        icon: 'fa-umbrella-beach',
                        iconBg: '#fff5f5',
                        iconColor: '#e03131',
                        dateLabel: 'Holiday'
                    });
                }
            }
        });

        return events;
    }

    // Popover popup positioned above cell
    function openEventsPopover(year, month, day, dayEvents, cellElement) {
        const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        
        // Update Title
        document.getElementById("popoverTitle").innerText = `Events on ${monthNames[month]} ${day}, ${year}`;

        const body = document.getElementById("popoverBody");
        body.innerHTML = "";

        // Build HTML for each event
        dayEvents.forEach(evt => {
            const item = document.createElement("div");
            item.className = "calendar-event-item fade-in";

            let rightBadgeStyle = '';
            if (evt.type === 'birthday') rightBadgeStyle = 'background-color: #fff9db; color: #f08c00;';
            else if (evt.type === 'anniversary') rightBadgeStyle = 'background-color: #ebfbee; color: #2b8a3e;';
            else if (evt.type === 'holiday') rightBadgeStyle = 'background-color: #fff5f5; color: #e03131;';

            item.innerHTML = `
                <div class="event-item-left">
                    <div class="event-item-icon" style="background-color: ${evt.iconBg}; color: ${evt.iconColor};">
                        <i class="fa ${evt.icon}"></i>
                    </div>
                    <div class="event-item-info">
                        <span class="event-item-title">${evt.title}</span>
                        <span class="event-item-subtitle">${evt.subtitle}</span>
                    </div>
                </div>
                <div class="event-item-right" style="${rightBadgeStyle}">
                    ${evt.dateLabel}
                </div>
            `;
            body.appendChild(item);
        });

        // Toggle popover visible
        const popover = document.getElementById("calendarEventPopover");
        
        // Reset styles to calculate bounds accurately
        popover.style.display = "block";
        popover.style.top = "0px";
        popover.style.left = "0px";
        
        // Calculate position relative to the .twisty-card parent
        const card = cellElement.closest('.twisty-card');
        if (card) {
            const cardRect = card.getBoundingClientRect();
            const cellRect = cellElement.getBoundingClientRect();
            const popoverRect = popover.getBoundingClientRect();
            
            let top = cellRect.top - cardRect.top - popoverRect.height - 10;
            let left = cellRect.left - cardRect.left + (cellRect.width / 2) - (popoverRect.width / 2);
            
            // Ensure it doesn't go outside the card horizontally
            if (left < 10) left = 10;
            if (left + popoverRect.width > cardRect.width - 10) {
                left = cardRect.width - popoverRect.width - 10;
            }
            
            // If there's no space above, show it below the cell
            if (top < 10) {
                top = cellRect.bottom - cardRect.top + 10;
            }
            
            popover.style.top = top + "px";
            popover.style.left = left + "px";
        }
    }

    function closePopover() {
        document.getElementById("calendarEventPopover").style.display = "none";
    }

    // Dismiss on click outside
    document.addEventListener("click", function(event) {
        const popover = document.getElementById("calendarEventPopover");
        const isClickInside = popover.contains(event.target);
        const isCalendarCell = event.target.closest(".calendar-day-cell");
        
        if (!isClickInside && !isCalendarCell && popover.style.display === "block") {
            closePopover();
        }
    });
</script>
@endsection

