<?php

use App\Http\Controllers\EmployeeFormController;
use App\Http\Controllers\ProfileController;

Route::redirect('/', '/employee/login');
Route::get('/registration', [EmployeeFormController::class, 'create'])->name('employee.form');
Route::post('/submit', [EmployeeFormController::class, 'store'])->name('employee.store');
Route::view('/terms-and-conditions', 'employee.terms')->name('terms');

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\EmployeeController;

Route::middleware(['auth', 'role:Super Admin|HR Manager'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard/blood-group', [DashboardController::class, 'searchBloodGroup'])->name('dashboard.blood-group');
    Route::post('employees/import', [EmployeeController::class, 'import'])->name('employees.import');
    Route::resource('employees', EmployeeController::class);
    Route::post('employees/{employee}/status', [EmployeeController::class, 'updateStatus'])->name('employees.status');
    Route::get('employees/{employee}/id-card', [EmployeeController::class, 'idCard'])->name('employees.id-card');
    Route::get('employees/{employee}/experience-certificate', [EmployeeController::class, 'experienceCertificate'])->name('employees.experience-certificate');

    Route::resource('leave-types', \App\Http\Controllers\Admin\LeaveTypeController::class)->except(['create', 'show', 'edit']);
    
    // Leave Requests
    Route::get('leave/export', [\App\Http\Controllers\Admin\LeaveRequestController::class, 'export'])->name('leave.export');
    Route::get('leave', [\App\Http\Controllers\Admin\LeaveRequestController::class, 'index'])->name('leave.index');
    Route::delete('leave/{leave}', [\App\Http\Controllers\Admin\LeaveRequestController::class, 'destroy'])->name('leave.destroy');
    Route::post('leave/{leave}/approve', [\App\Http\Controllers\Admin\LeaveRequestController::class, 'approve'])->name('leave.approve');
    Route::post('leave/{leave}/reject', [\App\Http\Controllers\Admin\LeaveRequestController::class, 'reject'])->name('leave.reject');
    // Attendance
    Route::get('attendance/export', [\App\Http\Controllers\Admin\AttendanceController::class, 'export'])->name('attendance.export');
    Route::resource('attendance', \App\Http\Controllers\Admin\AttendanceController::class)->except(['create', 'show', 'edit', 'update']);
    Route::resource('assets', \App\Http\Controllers\Admin\AssetController::class)->except(['create', 'show', 'edit']);
    Route::post('assets/{asset}/assign', [\App\Http\Controllers\Admin\AssetController::class, 'assign'])->name('assets.assign');
    Route::post('assets/return/{assignment}', [\App\Http\Controllers\Admin\AssetController::class, 'returnAsset'])->name('assets.return');

    Route::resource('api-tokens', \App\Http\Controllers\Admin\ApiTokenController::class)->only(['index', 'store', 'destroy']);

    Route::get('/organization/{type}', [\App\Http\Controllers\Admin\OrganizationController::class, 'index'])->name('organization.index');
    Route::post('/organization/{type}', [\App\Http\Controllers\Admin\OrganizationController::class, 'store'])->name('organization.store');
    Route::put('/organization/{type}/{id}', [\App\Http\Controllers\Admin\OrganizationController::class, 'update'])->name('organization.update');
    Route::delete('/organization/{type}/{id}', [\App\Http\Controllers\Admin\OrganizationController::class, 'destroy'])->name('organization.destroy');
});

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

// Employee Portal Routes
Route::prefix('employee')->name('employee.')->group(function () {
    Route::get('/login', [\App\Http\Controllers\Employee\AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [\App\Http\Controllers\Employee\AuthController::class, 'login']);
    Route::post('/logout', [\App\Http\Controllers\Employee\AuthController::class, 'logout'])->name('logout');

    Route::middleware(['auth:employee', 'employee_password_reset'])->group(function () {
        Route::get('/dashboard', function () {
            $employee = auth()->guard('employee')->user()->employee;
            $todayAttendance = \App\Models\Attendance::where('employee_id', $employee->id)->whereDate('date', \Carbon\Carbon::today())->first();
            
            // Calculate Weekly Chart Data
            $startOfWeek = \Carbon\Carbon::now()->startOfWeek();
            $endOfWeek   = \Carbon\Carbon::now()->endOfWeek();
            
            $weeklyAttendances = \App\Models\Attendance::where('employee_id', $employee->id)
                ->whereBetween('date', [$startOfWeek->toDateString(), $endOfWeek->toDateString()])
                ->get();
            
            $chartLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            $chartData   = [0, 0, 0, 0, 0, 0];
            
            foreach ($weeklyAttendances as $att) {
                $dayIndex = \Carbon\Carbon::parse($att->date)->dayOfWeekIso - 1;
                if ($dayIndex < 6 && $att->check_in && $att->check_out) {
                    $checkIn  = \Carbon\Carbon::parse($att->check_in);
                    $checkOut = \Carbon\Carbon::parse($att->check_out);
                    $hours = $checkIn->diffInMinutes($checkOut) / 60;
                    $chartData[$dayIndex] = round($hours, 1);
                }
            }

            // ── Celebrations (same logic as admin dashboard) ───────────────────────
            $startDate = now()->startOfDay();
            $endDate   = now()->addDays(7)->endOfDay(); // 7-day window for employee view

            $upcomingBirthdays = \App\Models\Employee::with('departmentRel', 'designationRel')
                ->where('status', 'Active')
                ->get()
                ->filter(function ($emp) use ($startDate, $endDate) {
                    if (!$emp->dob) return false;
                    $bdayThisYear = \Carbon\Carbon::parse($emp->dob)->year(now()->year)->startOfDay();
                    $bdayNextYear = \Carbon\Carbon::parse($emp->dob)->year(now()->year + 1)->startOfDay();
                    return $bdayThisYear->between($startDate, $endDate) || $bdayNextYear->between($startDate, $endDate);
                })
                ->sortBy(fn($emp) => \Carbon\Carbon::parse($emp->dob)->format('m-d'))
                ->values();

            $workAnniversaries = \App\Models\Employee::with('departmentRel', 'designationRel')
                ->where('status', 'Active')
                ->get()
                ->filter(function ($emp) use ($startDate, $endDate) {
                    if (!$emp->joining_date) return false;
                    $annivThisYear = \Carbon\Carbon::parse($emp->joining_date)->year(now()->year)->startOfDay();
                    $annivNextYear = \Carbon\Carbon::parse($emp->joining_date)->year(now()->year + 1)->startOfDay();
                    if ($annivThisYear->between($startDate, $endDate)) {
                        $emp->anniversary_years = now()->year - \Carbon\Carbon::parse($emp->joining_date)->year;
                        return true;
                    }
                    if ($annivNextYear->between($startDate, $endDate)) {
                        $emp->anniversary_years = (now()->year + 1) - \Carbon\Carbon::parse($emp->joining_date)->year;
                        return true;
                    }
                    return false;
                })
                ->sortBy(fn($emp) => \Carbon\Carbon::parse($emp->joining_date)->format('m-d'))
                ->values();

            // ── Calendar employees & holidays (same as admin) ──────────────────────
            $calendarEmployees = \App\Models\Employee::with('departmentRel')
                ->where('status', 'Active')
                ->get()
                ->map(fn($emp) => [
                    'name'         => $emp->name,
                    'dob'          => $emp->dob,
                    'joining_date' => $emp->joining_date,
                    'department'   => $emp->departmentRel->name ?? $emp->department ?? 'General',
                ]);

            $companyHolidays = [
                ['date' => '2026-01-01', 'name' => "New Year's Day"],
                ['date' => '2026-01-26', 'name' => 'Republic Day'],
                ['date' => '2026-05-01', 'name' => 'Labor Day'],
                ['date' => '2026-07-15', 'name' => 'Corporate Wellness Day'],
                ['date' => '2026-07-26', 'name' => 'Mid-Year Review Holiday'],
                ['date' => '2026-08-15', 'name' => 'Independence Day'],
                ['date' => '2026-10-02', 'name' => 'Gandhi Jayanti'],
                ['date' => '2026-11-01', 'name' => 'Karnataka Rajyotsava'],
                ['date' => '2026-12-25', 'name' => 'Christmas Day'],
            ];

            return view('employee.portal.dashboard', compact(
                'employee', 'todayAttendance', 'chartLabels', 'chartData',
                'upcomingBirthdays', 'workAnniversaries',
                'calendarEmployees', 'companyHolidays'
            ));
        })->name('dashboard');

        Route::post('/attendance/punch-in', [\App\Http\Controllers\Employee\AttendanceController::class, 'punchIn'])->name('attendance.punch-in');
        Route::post('/attendance/punch-out', [\App\Http\Controllers\Employee\AttendanceController::class, 'punchOut'])->name('attendance.punch-out');

        Route::get('/attendance', function () {
            $employee = auth()->guard('employee')->user()->employee;

            // All attendance records (all time, for calendar)
            $allRecords = \App\Models\Attendance::where('employee_id', $employee->id)->get();

            // This month's records for the table
            $records = $allRecords->filter(fn($a) =>
                \Carbon\Carbon::parse($a->date)->month === now()->month &&
                \Carbon\Carbon::parse($a->date)->year  === now()->year
            );

            // Monthly stats (current month)
            $stats = [
                'present' => $records->where('status', 'Present')->count(),
                'absent'  => $records->where('status', 'Absent')->count(),
                'halfday' => $records->where('status', 'Half-Day')->count(),
                'late'    => $records->where('status', 'Late')->count(),
                'leave'   => $records->where('status', 'Leave')->count(),
            ];

            // Build date-keyed map for JS calendar (all records)
            $calendarData = $allRecords->keyBy(fn($a) => $a->date)
                ->map(fn($a) => [
                    'status'    => $a->status,
                    'check_in'  => $a->check_in  ? \Carbon\Carbon::parse($a->check_in)->format('h:i A')  : null,
                    'check_out' => $a->check_out ? \Carbon\Carbon::parse($a->check_out)->format('h:i A') : null,
                ]);

            $todayAttendance = $allRecords->first(fn($a) =>
                \Carbon\Carbon::parse($a->date)->isToday()
            );

            return view('employee.portal.attendance', compact(
                'employee', 'records', 'allRecords', 'stats', 'calendarData', 'todayAttendance'
            ));
        })->name('attendance.index');

        Route::get('/reset-password', [\App\Http\Controllers\Employee\AuthController::class, 'showResetPasswordForm'])->name('password.reset')->withoutMiddleware('employee_password_reset');
        Route::post('/reset-password', [\App\Http\Controllers\Employee\AuthController::class, 'updatePassword'])->name('password.update')->withoutMiddleware('employee_password_reset');

        // ── Leaves ────────────────────────────────────────────────────────────
        Route::get('/leaves', function () {
            $employee = auth()->guard('employee')->user()->employee;
            $requests = \App\Models\LeaveRequest::where('employee_id', $employee->id)
                ->orderByDesc('created_at')->get();
            return view('employee.portal.leaves', compact('employee', 'requests'));
        })->name('leaves.index');

        Route::post('/leaves', function (\Illuminate\Http\Request $request) {
            $employee = auth()->guard('employee')->user()->employee;
            $data = $request->validate([
                'start_date' => 'required|date|after_or_equal:today',
                'end_date'   => 'required|date|after_or_equal:start_date',
                'reason'     => 'nullable|string|max:500',
            ]);
            $start = \Carbon\Carbon::parse($data['start_date']);
            $end   = \Carbon\Carbon::parse($data['end_date']);
            $days  = $start->diffInWeekdays($end) + 1;
            \App\Models\LeaveRequest::create([
                'employee_id'   => $employee->id,
                'leave_type_id' => null,
                'start_date'    => $data['start_date'],
                'end_date'      => $data['end_date'],
                'total_days'    => $days,
                'reason'        => $data['reason'] ?? null,
                'status'        => 'Pending',
            ]);
            return redirect()->route('employee.leaves.index')->with('success', 'Leave request submitted successfully!');
        })->name('leaves.store');

        // ── Profile ───────────────────────────────────────────────────────────
        Route::get('/profile-view', function () {
            $employee = auth()->guard('employee')->user()->employee;
            $employee->load('departmentRel', 'designationRel', 'education', 'experience');
            return view('employee.portal.profile', compact('employee'));
        })->name('profile.index');
    });
});
